import { randomInt } from 'node:crypto';
import { ROLES } from './roles.mjs';

const width = 15;
const dieSides = 12;
const compassSteps = 3;
const cell = (x, y) => y * width + x;
const entrance = cell(1, 13);
const archive = cell(5, 7);
const rooms = [
  [3, 11, 'Sala del Umbral', 'umbral', [[2, 10]]],
  [3, 7, 'Sala de los Espejos', 'espejos', [[1, 7]]],
  [3, 3, 'Biblioteca', 'biblioteca', [[5, 3]]],
  [7, 3, 'Taller de Runas', 'runas', [[9, 3]]],
  [11, 3, 'Armería', 'armeria', [[13, 3]]],
  [11, 7, 'Galería de las Sombras', 'sombras', [[9, 7], [13, 7]]],
  [7, 11, 'Galería de Ignar', 'ignar', [[9, 11]]],
  [11, 11, 'Santuario de Ignar', 'santuario', [[13, 10], [13, 11]]],
];

export function makeBoard(count) {
  const tiles = Array(width * width).fill(null);
  const corridor = [1, 5, 9, 13];
  for (let y = 1; y < 14; y++) {
    for (let x = 1; x < 14; x++) {
      if (corridor.includes(x) || corridor.includes(y)) tiles[cell(x, y)] = { kind: 'floor' };
    }
  }

  const selectedRooms = [...rooms.slice(0, count - 2), ...rooms.slice(-2)];
  const doorsByRoom = selectedRooms.map(([x, y, , , sideDoors]) =>
    [[x, y + 2], ...sideDoors].map(([doorX, doorY]) => cell(doorX, doorY)));
  const challengeDoors = doorsByRoom.map(([mainDoor]) => mainDoor);
  const challengeSquares = selectedRooms.map(([x, y, name, theme], index) => {
    for (let dy = -1; dy <= 1; dy++) {
      for (let dx = -1; dx <= 1; dx++) {
        tiles[cell(x + dx, y + dy)] = { kind: 'room', room: index, name, theme };
      }
    }
    tiles[cell(x, y)] = { kind: 'seal', room: index, name, theme };
    for (const door of doorsByRoom[index]) {
      tiles[door] = { kind: 'door', room: index, name, theme };
    }
    return cell(x, y);
  });

  // Archivo opcional. Las antiguas trampas de pasillo se sustituyen por mecanismos ocultos en puertas.
  tiles[cell(5, 6)] = { kind: 'floor' };
  tiles[cell(5, 7)] = { kind: 'archive' };
  // Hay más hallazgos y un pergamino que entrega una pista gradual dentro de un reto.
  const loot = [
    [4, 5, 'amuleto'], [9, 10, 'pocion'], [6, 9, 'reloj'], [10, 9, 'brujula'],
    [7, 9, 'pergamino'], [5, 13, 'pocion'], [9, 5, 'amuleto'], [13, 5, 'brujula'],
    [9, 13, 'reloj'], [5, 1, 'pergamino'], [13, 1, 'pocion'],
  ];
  for (const [x, y, item] of loot) {
    if (tiles[cell(x, y)]?.kind === 'floor') tiles[cell(x, y)] = { kind: 'item', item };
  }
  const chestSquare = cell(12, 11);
  tiles[chestSquare] = { kind: 'chest-sealed', room: count - 1, name: 'Cofre del Santuario', theme: 'santuario' };
  tiles[entrance] = { kind: 'entrance' };

  const config = { width, tiles, entrance, challengeSquares, challengeDoors, chestSquare };
  const startingBoard = createBoardState();
  // Medimos por el tablero desde la casilla inicial, con las salas futuras bloqueadas.
  // Calculamos todas las distancias antes de colocar las trampas. Si hay empate, prima la puerta principal.
  const shortestEntries = doorsByRoom.map((doors, step) => {
    const paths = pathsWithin({ step, board: startingBoard }, config, tiles.length);
    const distance = door => paths.get(door)?.length ?? Infinity;
    return doors.reduce((closest, door) => distance(door) < distance(closest) ? door : closest);
  });
  for (const door of shortestEntries) tiles[door].hiddenTrap = true;
  return config;
}

export function createBoardState() {
  return {
    position: entrance,
    entrance,
    checkpoint: entrance,
    moves: 0,
    turn: 0,
    rollsAtSeal: 0,
    revision: 0,
    rollValue: null,
    remainingSteps: 0,
    passiveUsed: 0,
    nextMoveBonus: 0,
    passiveLog: '',
    openedRooms: [],
    visitedSpecial: [],
    inventory: { amuleto: 0, reloj: 0, pocion: 0, brujula: 0, pergamino: 0 },
    shieldArmed: false,
    compassArmed: false,
  };
}

function neighborsOf(index, columns) {
  const x = index % columns;
  const neighbors = [index - columns, index + columns];
  if (x > 0) neighbors.push(index - 1);
  if (x < columns - 1) neighbors.push(index + 1);
  return neighbors;
}

function tileAvailable(tile, team, config) {
  if (!tile || (tile.room !== undefined && tile.room > team.step)) return false;
  if (tile.kind === 'chest-sealed') return team.step >= config.challengeSquares.length;
  if (tile.kind === 'room' || tile.kind === 'seal') return team.board.openedRooms.includes(tile.room);
  return true;
}

function rollsLeft(team, maxRolls) {
  return maxRolls > 0 ? Math.max(0, maxRolls - (team.board.rollsAtSeal ?? 0)) : null;
}

function encounterIndex(team, config) {
  return Math.min(team.step, config.challengeSquares.length - 1);
}

function rollRange(board) {
  return board.remainingSteps > 0 ? board.remainingSteps + (board.compassArmed ? compassSteps : 0) : 0;
}

export function compassActive(board) {
  return board.compassArmed || (board.lastRollBonus ?? 0) >= compassSteps;
}

function pathsWithin(team, config, limit, goal) {
  const b = team.board;
  const encounter = encounterIndex(team, config);
  const seal = config.challengeSquares[encounter];
  const paths = new Map([[b.position, []]]);
  for (const [from, path] of paths) {
    if (from === goal && path.length) return new Map([[from, path]]);
    if (path.length >= limit) continue;
    const tile = config.tiles[from];
    const isChallengeDoor = tile.kind === 'door' && tile.room === encounter;
    const hasTrap = (tile.kind === 'trap' || tile.hiddenTrap) && !b.visitedSpecial.includes(from);
    if (path.length && (from === seal || isChallengeDoor || hasTrap)) continue;

    for (const next of neighborsOf(from, config.width)) {
      if (paths.has(next) || !tileAvailable(config.tiles[next], team, config)) continue;
      paths.set(next, [...path, next]);
    }
  }
  if (goal !== undefined) return new Map();
  paths.delete(b.position);
  return paths;
}

function movementOptions(team, config, maxRolls) {
  const b = team.board;
  const exhausted = rollsLeft(team, maxRolls) === 0;
  const range = rollRange(b);
  const rolled = range > 0;
  const lastRoll = exhausted && rolled;
  // Una expulsión obliga a regresar al mismo objetivo, aunque ya se haya gastado la última tirada.
  const reentry = exhausted && !rolled && (team.lastPenalty?.kind === 'retreat' || team.retryAt > 0);
  const paths = rolled ? pathsWithin(team, config, range) : new Map();
  const lifeCostSquares = [];
  let directTarget;
  if (lastRoll || reentry) {
    const encounter = encounterIndex(team, config);
    const seal = config.challengeSquares[encounter];
    const inRoom = config.tiles[b.position]?.room === encounter && b.openedRooms.includes(encounter);
    const goal = inRoom ? seal : config.challengeDoors[encounter];
    if (reentry) {
      const directPath = pathsWithin(team, config, config.tiles.length, goal).get(goal);
      if (directPath) paths.set(goal, directPath);
    }
    if (paths.has(goal)) {
      directTarget = goal;
    }
    if (lastRoll) {
      for (const square of paths.keys()) {
        const tile = config.tiles[square];
        const entersRoom = tile.kind === 'door' && tile.room === encounter;
        if (square !== seal && !entersRoom && !(team.step > encounter && square === config.chestSquare)) {
          lifeCostSquares.push(square);
        } else {
          directTarget ??= square;
        }
      }
    }
  }
  const refillRequired = exhausted && !rolled && directTarget === undefined;
  return { paths, lastRoll, reentry, directTarget, lifeCostSquares, refillRequired };
}

function nextObjective(team, config, paths, activeRoom, directTarget) {
  const encounter = encounterIndex(team, config);
  const kind = activeRoom?.index === encounter ? 'seal' : 'door';
  const square = kind === 'seal' ? config.challengeSquares[encounter] : config.challengeDoors[encounter];
  const { name, theme } = config.tiles[square];
  const objective = { kind, square, name, theme };
  if (paths.size === 0) return objective;
  if (directTarget !== undefined) return { ...objective, recommended: directTarget };

  // La guía usa entradas principales. El equipo puede explorar las puertas laterales.
  const distances = new Map([[square, 0]]);
  for (const [from, distance] of distances) {
    for (const next of neighborsOf(from, config.width)) {
      const tile = config.tiles[next];
      if (tile?.kind === 'door' && next !== config.challengeDoors[tile.room]) continue;
      if (!distances.has(next) && tileAvailable(tile, team, config)) {
        distances.set(next, distance + 1);
      }
    }
  }
  let nearest = distances.get(team.board.position) ?? Infinity;
  for (const target of paths.keys()) {
    const distance = distances.get(target) ?? Infinity;
    if (distance >= nearest) continue;
    nearest = distance;
    objective.recommended = target;
  }
  return objective;
}

function phaseOf(team, config) {
  if (team.deadAt != null) return 'dead';
  if (team.step >= config.challengeSquares.length) {
    return [config.challengeSquares.at(-1), config.chestSquare].includes(team.board.position) ? 'chest' : 'travel';
  }
  return team.board.position === config.challengeSquares[team.step] ? 'challenge' : 'travel';
}

export function boardView(team, config, maxRolls = 0) {
  const b = team.board;
  const phase = phaseOf(team, config);
  const remainingRolls = rollsLeft(team, maxRolls);
  const movement = phase === 'travel' ? movementOptions(team, config, maxRolls) : { paths: new Map() };
  const { paths, ...options } = movement;
  const positionTile = config.tiles[b.position];
  const activeRoom = positionTile?.room !== undefined && b.openedRooms.includes(positionTile.room)
    ? { index: positionTile.room, name: positionTile.name, theme: positionTile.theme }
    : null;
  const tiles = config.tiles.map((tile, index) => {
    if (!tile) return tile;
    if (tile.kind === 'item') return { kind: b.visitedSpecial.includes(index) ? 'floor' : 'item' };
    const { hiddenTrap, ...publicTile } = tile;
    if (tile.room === undefined || tile.kind === 'door' || b.openedRooms.includes(tile.room)) return publicTile;
    return { kind: 'hidden', theme: tile.theme };
  });
  // El cofre se ve cerrado al descubrir el Santuario y se activa al superar su sello final.
  if (phase === 'chest') {
    tiles[config.chestSquare] = { ...config.tiles[config.chestSquare], kind: team.finishedAt != null ? 'chest-open' : 'chest', name: 'Cofre de las runas' };
  }
  const objective = phase === 'travel' ? nextObjective(team, config, paths, activeRoom, movement.directTarget) : null;
  const returningToChest = phase === 'travel' && team.step >= config.challengeSquares.length;
  return {
    ...b, remainingSteps: rollRange(b), compassActive: compassActive(b),
    phase, maxRolls, remainingRolls, ...options, returningToChest, paths: Object.fromEntries(paths), tiles, activeRoom, objective,
  };
}

function passiveForRoll(team, die) {
  const board = team.board;
  const role = ROLES.find(item => item.id === team.role);
  if (!role) return { bonus: 0, message: '' };

  if (board.nextMoveBonus) {
    const bonus = board.nextMoveBonus;
    board.nextMoveBonus = 0;
    return { bonus, message: board.passiveLog };
  }

  if (team.role === 'orco' && die >= 9 && board.passiveUsed < role.charges) {
    board.passiveUsed++;
    return { bonus: 1, message: `${role.ability}: +1 paso.` };
  }
  if (team.role === 'elfo' && die <= 3 && board.passiveUsed < role.charges) {
    board.passiveUsed++;
    return { bonus: 1, message: `${role.ability}: +1 paso.` };
  }
  if (team.role === 'humano' && board.passiveUsed < role.charges) {
    board.passiveUsed++;
    return { bonus: 1, message: `${role.ability}: +1 paso.` };
  }
  return { bonus: 0, message: '' };
}

export function rollMovement(team, config, face = () => randomInt(1, dieSides + 1), maxRolls = 0) {
  const b = team.board;
  if (phaseOf(team, config) !== 'travel' || b.remainingSteps > 0 || rollsLeft(team, maxRolls) === 0) return null;

  const die = face();
  if (!Number.isInteger(die) || die < 1 || die > dieSides) throw new Error('Resultado de dado no válido.');
  const passive = passiveForRoll(team, die);
  const compassBonus = b.compassArmed ? compassSteps : 0;
  b.compassArmed = false;
  b.rollValue = die;
  b.remainingSteps = die + passive.bonus + compassBonus;
  b.lastRollBonus = passive.bonus + compassBonus;
  const bonuses = [passive.message, compassBonus ? 'Brújula arcana: +3 pasos.' : ''].filter(Boolean).join(' ');
  b.passiveLog = bonuses || b.passiveLog;
  b.turn++;
  b.rollsAtSeal = (b.rollsAtSeal ?? 0) + 1;
  b.revision++;
  return { die, movement: b.remainingSteps, bonus: b.lastRollBonus, passive: bonuses };
}

export function moveTeam(team, config, target, maxRolls = 0, allowLifeCost = false) {
  const movement = movementOptions(team, config, maxRolls);
  const path = movement.paths.get(target);
  if (!path) return null;
  const lifeCost = movement.lifeCostSquares.includes(target);
  if (lifeCost && !allowLifeCost) return null;

  const b = team.board;
  const origin = b.position;
  const tile = config.tiles[target];
  const result = { path };
  b.position = target;
  b.moves++;
  if (b.remainingSteps > 0) b.compassArmed = false;
  b.remainingSteps = 0;
  b.rollValue = null;
  b.lastRollBonus = 0;
  b.revision++;

  if (tile.kind === 'door' && tile.hiddenTrap && !b.visitedSpecial.includes(target)) {
    springTrap(team, target, path, origin, result, true);
  }

  if (tile.kind === 'door' && !result.damage && !b.openedRooms.includes(tile.room)) {
    b.openedRooms.push(tile.room);
    result.openedDoor = tile.name;
    result.openedRoom = { index: tile.room, name: tile.name, theme: tile.theme };
    result.feedback ??= 'La puerta cede y revela la sala.';
  }

  if (!b.visitedSpecial.includes(target) && ['archive', 'trap', 'item'].includes(tile.kind)) {
    if (tile.kind === 'trap') {
      springTrap(team, target, path, origin, result, false);
    } else {
      b.visitedSpecial.push(target);
    }
    if (tile.kind === 'archive') {
      if (team.step < config.challengeSquares.length) {
        team.hints[team.step] = Math.max(1, team.hints[team.step]);
        result.feedback = 'Habéis encontrado un indicio. La primera pista aparecerá en el reto actual.';
      }
    } else if (tile.kind === 'item') {
      b.inventory[tile.item]++;
      result.item = tile.item;
    }
  }

  // Cruzar una puerta del desafío actual activa su sello en el mismo movimiento.
  if (tile.kind === 'door' && tile.room === encounterIndex(team, config) && !result.damage) {
    b.position = config.challengeSquares[tile.room];
    result.enteredDoor = true;
  }
  if (lifeCost && !result.damage) {
    result.feedback = refillRollsWithLife(team);
  } else if (movement.lastRoll && result.damage && team.deadAt == null) {
    b.rollsAtSeal = 0;
    result.feedback += ' Recuperáis las tiradas del sello.';
  }
  return result;
}

function loseLife(team, reason) {
  team.health = Math.max(0, (team.health ?? 3) - 1);
  if (team.health === 0) {
    team.deadAt = Date.now();
    team.deathReason = reason;
    team.deathChallengeIndex = team.step;
  }
}

export function refillRollsWithLife(team) {
  loseLife(team, 'roll-budget');
  team.board.rollsAtSeal = 0;
  return team.health === 0
    ? 'Habéis perdido vuestra última vida al seguir explorando.'
    : `Perdéis 1 punto de vida (${team.health}/3) por seguir explorando y recuperáis las tiradas del sello.`;
}

function springTrap(team, target, path, origin, result, concealed) {
  const board = team.board;
  board.visitedSpecial.push(target);
  result.trapTriggered = true;
  const role = ROLES.find(item => item.id === team.role);
  if (team.role === 'enano' && role && board.passiveUsed < role.charges) {
    board.passiveUsed++;
    board.passiveLog = `${role.ability}: habéis evitado una trampa.`;
    result.feedback = concealed
      ? `¡Mecanismo oculto! ${board.passiveLog}`
      : board.passiveLog;
  } else if (board.shieldArmed) {
    board.shieldArmed = false;
    result.feedback = concealed
      ? '¡Mecanismo oculto! El amuleto protector ha bloqueado la trampa.'
      : 'El amuleto protector ha bloqueado la trampa.';
  } else {
    loseLife(team, 'trap');
    board.position = path.at(-2) ?? origin;
    result.damage = 1;
    result.feedback = team.health === 0
      ? 'La trampa oculta os quita el último punto de vida. La partida ha terminado.'
      : `La trampa oculta os quita 1 punto de vida (${team.health}/3) y os hace retroceder una casilla.`;
  }
}

export function challengeExit(config, index) {
  const door = config.challengeDoors[index];
  return neighborsOf(door, config.width).find(square => config.tiles[square]?.kind === 'floor') ?? config.entrance;
}

export function retreatFromSanctuary(team, config) {
  team.board.position = challengeExit(config, config.challengeDoors.length - 1);
  team.board.revision++;
}

export function afterSeal(team, count) {
  if (team.step < count) team.board.rollsAtSeal = 0;
  if (team.role !== 'no-muerto' || team.step > 2 || team.board.passiveUsed >= 2) return '';
  team.board.passiveUsed++;
  team.board.nextMoveBonus = 1;
  team.board.passiveLog = 'Marcha espectral: +1 paso en el próximo movimiento.';
  return team.board.passiveLog;
}
