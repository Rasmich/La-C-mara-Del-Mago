// Cada pasiva afecta al desplazamiento o a las trampas y tiene usos limitados.
export const ROLES = [
  { id: 'enano', name: 'Enanos', ability: 'Botas de la montaña', description: 'Ignoráis las tres primeras trampas.', position: 0, charges: 3 },
  { id: 'orco', name: 'Orcos', ability: 'Embestida del clan', description: 'Con un resultado del 9 al 12, ganáis un paso adicional. Tres activaciones.', position: 1, charges: 3 },
  { id: 'no-muerto', name: 'No muertos', ability: 'Marcha espectral', description: 'Tras superar los dos primeros sellos, ganáis un paso en el siguiente movimiento.', position: 2, charges: 2 },
  { id: 'elfo', name: 'Elfos', ability: 'Viento del bosque', description: 'Con un resultado del 1 al 3, ganáis un paso adicional. Tres activaciones.', position: 3, charges: 3 },
  { id: 'humano', name: 'Humanos', ability: 'Ingenio viajero', description: 'Los tres primeros movimientos ganan un paso adicional.', position: 4, charges: 3 },
];
