# Auditoría de La Cámara del Mago

**Versión revisada históricamente:** 1.6.0. **Versión entregada entonces:** 1.7.1. **Fecha de la revisión histórica:** 12 de noviembre de 2026.

## Trampas de entrada y objetos ocultos · 1.9.19

La puerta con el camino más corto desde la casilla inicial oculta una trampa de un solo uso por pareja. Si hace daño, el equipo queda fuera de la sala y puede intentarlo por la misma puerta. Los objetos comparten un rombo en el mapa. Se revelan al terminar el movimiento en su casilla.

## Alcance de cada tirada · 1.9.18

Las rutas disponibles, incluida la entrada al sello en la última tirada, quedan dentro del alcance calculado por el servidor. Se muestran por separado el valor del dado y las bonificaciones. Cada brújula se aplica a un solo movimiento, incluso si se activa después de tirar.

## Última tirada por sello · 1.9.17

El tablero avisa cuando queda una tirada. En esa última tirada se elige entre el acceso directo al sello o un movimiento de exploración por un punto de vida. La pareja confirma el coste antes de moverse. Al agotar las tiradas, el regreso directo solo está disponible si un fallo de respuesta expulsó a la pareja del sello o del cofre.

## Penalizaciones en la demo y en Clásico · 1.9.16

La demo usa las reglas de Clásico. El primer fallo de un sello o de la cerradura os deja en el pasillo junto a la puerta de la sala. El segundo os devuelve a la casilla inicial y al tercero aparece la escena de derrota de Ignar. Tras los dos primeros fallos hay que volver por el tablero para seguir.

## Puertas, tiradas y Santuario · 1.9.15

Los objetos y el archivo dejan pasar. Sigue siendo necesario acabar el movimiento en su casilla para recoger un objeto o consultar el archivo. Cada puerta muestra el número de su reto, incluso si está cerrada.

El docente puede fijar cuántas tiradas se permiten entre sellos. Con el presupuesto agotado, el único destino disponible es el acceso directo al sello. Los fallos conservan las tiradas ya gastadas. El último reto y la combinación del cofre expulsan del Santuario al fallar y obligan a volver por el mapa.

## Lectura del tablero y demo breve · 1.9.14

Las coordenadas se sitúan en bandas separadas de las gárgolas. Tras la tirada, las casillas alcanzables tienen un fondo dorado y la puerta objetivo alcanzable conserva un tono verde claro. El destino sugerido se marca con un borde discontinuo. El texto de cada destino indica su distancia.

La demo permite resolver tres retos de cultura general sin publicar una sala. Los fallos permiten reintentar desde el mismo sello. Los valores de la [velocidad de la luz en el vacío](https://physics.nist.gov/cuu/Constants/Value/c.html) y de la [aceleración estándar de caída libre](https://www.nist.gov/pml/special-publication-811/nist-guide-si-appendix-b-conversion-factors/nist-guide-si-appendix-b8) se han contrastado con NIST. La cerradura reúne las runas ganadas y el orden en que se deben introducir sus cifras.

## Mapa de mesa y partidas guardadas · 1.9.13

El tablero usa una textura de piedra común y una paleta de pizarra y ocre. Las salas se reconocen por su pavimento y un emblema propio. La textura respeta la geometría y las coordenadas de las casillas. Las rutas, los destinos al alcance y las puertas activas conservan sus marcas.

Las salas publicadas, los materiales y el progreso de las parejas se guardan en el ordenador docente al publicar o jugar. Se recuperan en **Modo docente → Salas abiertas** al iniciar desde la misma carpeta. El reloj se pausa con el servidor cerrado. Si el proceso se interrumpe de golpe, el reloj puede recuperar hasta unos cinco segundos. La demo y la prueba docente son temporales.

## Miniaturas y lectura del tablero · 1.9.12

Cada raza tiene su propia figura con peana. Son renders de modelos 3D y se ven tanto en las cartas como en el mapa. Después de tirar se puede previsualizar el recorrido al señalar o enfocar un destino. Al confirmar el movimiento, la miniatura sigue la ruta autorizada por el servidor. Las gárgolas se amplían y se desplazan hacia fuera para despejar las primeras casillas.

El premio del cofre queda visible en el formulario docente.

## Gárgolas y título gótico · 1.9.11

Las gárgolas se ven un 47 % más grandes. El dibujo de mayor resolución y la peana más oscura separan la silueta del muro. El título usa la tipografía gótica Grenze Gotisch, de Omnibus-Type. La fuente se incluye en el juego y su licencia está en `licencias/Grenze-Gotisch-OFL.txt`.

## Muralla, gárgolas e Ignar · 1.9.10

Las casillas vacías del perímetro muestran un aparejo de piedra. En las cuatro esquinas hay gárgolas cenitales orientadas hacia el centro. La imagen se generó con ImageGen a partir de una gárgola gótica de caliza, vista a 90 grados desde arriba, con la cabeza hacia el norte, las alas extendidas y fondo transparente. El recurso del juego está en `public/gargola.webp`.

La entrada a las dos fases de Ignar muestra una llamarada que sale de la boca del dragón, ilumina la escena y deja unas brasas. El juego usa la ilustración original de Ignar recortada para la aparición en `public/ignar.webp`. Con la opción de reducir el movimiento, la aparición se muestra como una imagen fija.

## Acceso a los desafíos · 1.9.9

El dado y el siguiente objetivo se muestran encima del mapa. La puerta del desafío actual se resalta con su coordenada. Tras tirar, el juego sugiere una casilla al alcance o permite elegir otra. Las puertas de desafíos posteriores llevan un candado y explican qué sello las desbloquea.

Al cruzar una puerta disponible del desafío actual, la pareja llega al sello en el mismo movimiento. El botón «Ir al desafío» lleva a la pregunta. Al superarlo, «Continuar la expedición» vuelve al mapa con el nuevo objetivo. Las trampas y los retrocesos se aplican antes de entrar.

## Dodecaedro · 1.9.8 · 18 de noviembre de 2026

El dado ahora es un dodecaedro regular de doce caras pentagonales. Mantiene el giro, el rebote y la sombra fija. El servidor sortea un resultado del 1 al 12, que se muestra en la cara superior y determina el alcance base.

El paso adicional de los orcos se activa del 9 al 12 y el de los elfos del 1 al 3, con un máximo de tres usos por partida para cada raza.

## Dado tridimensional · 1.9.7 · 18 de noviembre de 2026

El dado se dibuja a partir de un modelo 3D con seis caras pentagonales y tres rombos. Sus cifras permanecen grabadas en las mismas caras mientras gira y rebota. Al terminar la animación se ve arriba la cifra obtenida y se habilitan las casillas de movimiento. La sombra se dibuja por separado y permanece en el tablero. Con movimiento reducido, el resultado se presenta directamente.

## Dado de nueve caras, aspecto de reto y Bolsa · 1.9.6 · 18 de noviembre de 2026

Se reemplaza la figura cúbica por un dado poliédrico facetado con nueve caras numeradas del 1 al 9. La animación se aplica solo al cuerpo: la elipse de sombra permanece fija en el tablero. El resultado de la tirada continúa mostrándose en el estado de movimiento y se genera en el servidor.

Al abrir un sello, la zona de reto y la biblioteca lateral cambian de la paleta morada a una paleta verde azulado, con contraste cálido para las runas y señal visible «Reto activo · Sala del sello».

El mapa ofrece hasta 18 puertas, incluidas entradas alternativas, y camufla tres mecanismos en puertas concretas. No hay marcas, rótulos ni coordenadas que permitan localizar las trampas antes de activarlas. El mecanismo se consume al dispararse, resta un punto de vida y retrocede una casilla; el amuleto y la pasiva del enano mantienen sus protecciones. Se agregan objetos hasta llegar a 11 hallazgos: amuletos, pociones, relojes, brújulas y pergaminos. El pergamino, utilizable dentro de un reto, revela el siguiente nivel de pista ya configurado para ese sello.

El marcador del equipo muestra el retrato de la raza elegida. Se animan el marcador, las rutas disponibles, las runas del marco, las puertas y los objetos, respetando la preferencia del sistema por movimiento reducido. La sección del inventario se presenta con el nombre breve «Bolsa».

No se ha ejecutado una partida completa en navegador ni pruebas automatizadas para esta entrega.

## Dado facetado y coordenadas del mapa · 1.9.5 · 18 de noviembre de 2026

Se redibuja el dado como un sólido isométrico de caras planas, aristas definidas, sombreado y cifras de alto contraste. La animación ahora inclina y gira el cuerpo; el valor aleatorio y el movimiento de 1 a 9 no cambian.

El tablero conserva sus 15 × 15 casillas y se amplía en pantalla para aprovechar mejor el espacio disponible. Se añaden letras A–O en el eje X y números 1–15 en el eje Y. Cada casilla incluye la coordenada en su texto accesible y en la ayuda emergente, lo que permite nombrarla con una referencia como H8.

La modificación se limita a la presentación del dado y del mapa; no cambia las reglas de desplazamiento, las casillas ni la selección de rutas. No se ha ejecutado una partida de navegador en esta entrega.

## Vidas, trampas, dado y cofre · 1.9.4 · 13 de noviembre de 2026

Se incorpora una reserva común de tres puntos de vida para la pareja, separada de los tres errores permitidos por reto. Cada trampa resta un punto y retrocede una casilla; la pasiva del enano y el amuleto conservan su función de protección. La poción restaura un punto de vida y, cuando la vida ya está completa, puede borrar un fallo del reto actual. Agotar la vida por una trampa termina la partida con una escena propia y queda diferenciado en el panel docente.

El dado mantiene el resultado aleatorio de 1 a 9 y la animación, con un cuerpo marfil redondeado, tres caras sombreadas y cifras negras inspiradas en la referencia visual del usuario. Al descubrir el Santuario, el mapa muestra su cofre cerrado. Tras superar el último sello, el icono se ilumina y se puede seleccionar para enfocar el formulario de combinación; el panel también explica que la recompensa se entrega después de abrirlo.

La vista de mapa muestra la vida restante y mantiene los errores del reto en un indicador separado. Se ha actualizado el texto de arranque para explicar el daño de las trampas, el uso de la poción y el acceso al cofre. No se ha realizado un nuevo piloto con alumnado en esta versión.

## Actualización de implementación · 1.9.2 · 13 de noviembre de 2026

La forma 3D inicial del dado no resultó legible: al mostrar ciertos resultados, la base ocupaba la vista y el número podía no coincidir con el estado de la tirada. La corrección visual queda registrada en la actualización 1.9.3.

Los cuatro objetos se recogen al terminar el movimiento sobre su casilla. El juego muestra el aviso de objeto conseguido y actualiza la mochila desplegable, desde la que se pueden activar los consumibles. El marco del mapa añade acabado de piedra, remaches, ornamentos de latón, señalética y adaptación a pantallas estrechas. Se conserva el diálogo **Reto superado** al completar cada desafío.

La simulación de equilibrio descrita más abajo corresponde a la versión histórica con el sistema de movimiento anterior; no se debe interpretar como una medición del nuevo tablero. Esta entrega no incluye un nuevo piloto con alumnado ni pruebas automatizadas.

## Corrección visual del dado · 1.9.3 · 13 de noviembre de 2026

Se sustituye la vista circular por un dado facetado inspirado en el del tablero espiral. La figura deja visibles sus caras y muestra sobre ella el mismo valor que anuncia el estado. Al pulsar **Tirar**, la figura rueda con una animación y se detiene en el resultado de 1 a 9 generado por el servidor. Se mantiene la entrada directa al tocar una casilla y el cambio de escena al abrir una puerta.

## Hallazgos y cambios

| Prioridad | Hallazgo | Resolución en 1.7.1 |
| --- | --- | --- |
| Alta | Retroceder 20 o 45 casillas puede convertir un error conceptual en una cadena larga de tiradas. La derrota impide practicar los sellos restantes. | Modo Aula opcional. Conserva el cronómetro y los sellos. Un error permite reconsiderar la respuesta y reintentar en el mismo punto. Clásico sigue seleccionado por defecto. |
| Alta | Una pista única ofrece el mismo grado de ayuda a quien necesita orientación y a quien ya ha intentado resolver el caso. | Primera pista de estrategia, editable, y segunda pista concreta. Se registra el nivel alcanzado y la pista reaparece al recargar o regresar al sello. |
| Alta | La recompensa cierra la ficción, pero ofrece poca información para comentar las decisiones tomadas durante la partida. | Cuaderno de expedición al ganar, perder o agotar el tiempo. Muestra intentos fallidos, ayudas y soluciones razonadas aportadas por el docente para los retos superados. Termina con una consigna de transferencia a un caso distinto. La demo incluye explicaciones para sus cinco retos. |
| Media | El total de fallos mezcla retos y combinación del cofre. Una poción reduce los fallos activos y podía ocultar el esfuerzo acumulado al leer el panel. | Contadores históricos de fallos y niveles de pista por reto en el panel docente. Se conservan las justificaciones escritas para revisión humana. |
| Media | Una respuesta enviada desde una vista desactualizada podía penalizar a la pareja después de que cambiara el tablero. | El servidor comprueba la revisión del tablero en las respuestas y en los intentos del cofre. También impide repetir un significado en los ejercicios de emparejamiento. |

En la entrega histórica 1.7.1, la aventura conservaba el tablero de 140 casillas, las cartas de raza, los objetos, el dragón y la cerradura de runas. La voz seguía desactivada.

La confirmación **Reto superado** muestra la runa y su cifra después de cada sello. Incluye mensajes propios para Ignar y el último sello.

## Uso didáctico

Para una primera sesión, selecciona **Aula** y prepara tres a cinco retos. Diseña cada sello para que la pareja aplique una idea de la unidad a una decisión del caso. En la primera pista, indica qué criterio comparar. En la segunda, señala el apartado del material o una evidencia concreta. Rellena la solución razonada para que aparezca en el cierre.

Reserva cinco minutos para el cuaderno y pide después una respuesta individual a un caso breve con datos nuevos. Evalúa si el estudiante identifica el concepto, lo aplica y justifica su decisión. El tiempo, las tiradas y los objetos dependen en parte del azar. Las pistas e intentos ayudan a detectar dónde intervenir durante la revisión.

Ejemplo para DAM. Dos programas crean un proceso hijo y leen su salida. En uno, la interfaz se congela al ejecutar el código. Pedid que localicen dónde se bloquea el flujo y que propongan una forma de mantener la interfaz operativa. La primera pista puede invitar a distinguir qué hilo ejecuta la espera. La segunda puede dirigir al apartado de operaciones bloqueantes.

## Equilibrio de las razas

Simulé 2.000 partidas por raza y configuración, con 3, 5 y 8 sellos. Las respuestas se dieron por correctas y no se consumieron objetos. La mayor distancia entre medias de tiradas fue de 2,23, con cinco sellos. La pasiva humana aportó 4,41 casillas de media con ocho sellos, frente a 12 para No muertos, aunque la distancia media de tiradas entre ambas razas fue de 0,55. Conservé las habilidades para poder observar el efecto de trampas, objetos y fallos en una sesión real.

## Verificación y siguiente prioridad

Probé la publicación y el acceso de parejas por HTTP, las dos pistas, la consulta de la pista revelada, la protección contra solicitudes desactualizadas, las penalizaciones del modo Clásico, los reintentos de Aula, el dragón, la combinación, la recompensa y los datos del cuaderno y del panel docente. Las pruebas aceleraron el reloj del servidor para recorrer ambos flujos. El diseño visual, la sesión con alumnado y el rendimiento con una clase completa quedan pendientes de validación.

Las partidas viven en memoria. Si el ordenador docente reinicia el servidor, se pierde la sesión. Para un siguiente desarrollo, priorizaría guardar y recuperar las partidas antes de ampliar el catálogo de objetos. Para evaluar el aprendizaje, priorizaría un piloto con una tarea individual de transferencia después del cierre.

## Referencias

- Ugo, López-Pernas, Gordillo y Tukiainen (2025). *Escape rooms for learning programming: A systematic literature review*. [DOI](https://doi.org/10.1002/rev3.70123).
- Grepperud (2025). *Educational escape games in primary and secondary education: a framework synthesis review*. [DOI](https://doi.org/10.1080/20004508.2025.2476271).
- Vorderobermeier, Abel y Sailer (2024). *Theoretical foundations and approaches in research on educational escape rooms*. [DOI](https://doi.org/10.1016/j.edurev.2024.100625).
- Veldkamp et al. (2022). *You escaped! How did you learn during gameplay?* [DOI](https://doi.org/10.1111/bjet.13194).
