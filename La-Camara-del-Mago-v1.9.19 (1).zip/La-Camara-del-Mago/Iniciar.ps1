$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

function Test-PortableNode {
    param([string]$Folder, [switch]$RequireReady)
    if ($RequireReady -and !(Test-Path -LiteralPath (Join-Path $Folder '.camara-ready') -PathType Leaf)) { return $false }
    return ((Test-Path -LiteralPath (Join-Path $Folder 'node.exe') -PathType Leaf) -and
        (Test-Path -LiteralPath (Join-Path $Folder 'npm.cmd') -PathType Leaf) -and
        (Test-Path -LiteralPath (Join-Path $Folder 'node_modules/npm/bin/npm-cli.js') -PathType Leaf))
}

function Expand-GameNodeArchive {
    param([string]$Archive, [string]$RuntimeRoot, [string]$Release, [string]$CacheTag)
    $cacheFull = [IO.Path]::GetFullPath($RuntimeRoot).TrimEnd([IO.Path]::DirectorySeparatorChar)
    $container = Join-Path $cacheFull ("$CacheTag-" + [guid]::NewGuid().ToString('N'))
    $null = [IO.Directory]::CreateDirectory($container)
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        # Extract directly to a fresh destination. No rename or directory move.
        [IO.Compression.ZipFile]::ExtractToDirectory($Archive, $container)
        $folder = Join-Path $container $Release
        if (!(Test-PortableNode $folder)) {
            throw 'La descarga de Node.js no contiene todos los archivos necesarios.'
        }
        [IO.File]::WriteAllText((Join-Path $folder '.camara-ready'), $Release)
        return $folder
    } catch {
        $originalFailure = $_
        # Only clean the private directory created by this invocation.
        try {
            $full = [IO.Path]::GetFullPath($container)
            if ([IO.Path]::GetDirectoryName($full) -eq $cacheFull -and
                [IO.Path]::GetFileName($full).StartsWith("$CacheTag-", [StringComparison]::OrdinalIgnoreCase) -and
                (Test-Path -LiteralPath $full -PathType Container)) {
                Remove-Item -LiteralPath $full -Recurse -Force -ErrorAction Stop
            }
        } catch { Write-Verbose 'Windows no permitio limpiar una instalacion incompleta; el siguiente intento usara otra carpeta.' }
        throw $originalFailure
    }
}

function Install-GameNode {
    param([string]$RuntimeRoot)
    $version = '24.22.2'
    $architecture = $env:PROCESSOR_ARCHITECTURE
    if ($env:PROCESSOR_ARCHITEW6432) { $architecture = $env:PROCESSOR_ARCHITEW6432 }
    $platform = if ($architecture) { @{ AMD64 = 'x64'; ARM64 = 'arm64' }[$architecture] } else { $null }
    if (!$platform) { throw 'El arranque automatico requiere Windows de 64 bits (x64 o ARM64).' }
    $hashes = @{
        x64 = 'ca1bff5d8ead13c9f2ea404a176db46bd430704d5b5113734049fa365e7799e2'
        arm64 = 'f47968c213105077f64c6510f007632c0ca2574802a0b5067c327c49abe1c468'
    }
    $release = "node-v$version-win-$platform"
    $cacheTag = "node-$version-$platform"
    $candidates = @(Get-ChildItem -LiteralPath $RuntimeRoot -Directory -Filter "$cacheTag-*" -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending)
    foreach ($candidate in $candidates) {
        $folder = Join-Path $candidate.FullName $release
        if (Test-PortableNode $folder -RequireReady) { return $folder }
    }
    $archive = Join-Path $RuntimeRoot ('.download-' + [guid]::NewGuid().ToString('N') + '.zip')
    try {
        Write-Host "Descargando Node.js $version desde nodejs.org..."
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -UseBasicParsing -Uri "https://nodejs.org/dist/v$version/$release.zip" -OutFile $archive -TimeoutSec 180
        $actualHash = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash
        if ($actualHash -ne $hashes[$platform]) { throw 'No se pudo verificar la descarga de Node.js. Vuelve a ejecutar Jugar.cmd.' }
        Write-Host 'Preparando Node.js en la cache del usuario...'
        return (Expand-GameNodeArchive -Archive $archive -RuntimeRoot $RuntimeRoot -Release $release -CacheTag $cacheTag)
    } finally {
        if (Test-Path -LiteralPath $archive -PathType Leaf) {
            try { Remove-Item -LiteralPath $archive -Force -ErrorAction Stop } catch { Write-Verbose 'El ZIP temporal sigue bloqueado por Windows.' }
        }
    }
}

$phase = 'Preparar la carpeta de arranque'
try {
    $cacheBase = $env:LOCALAPPDATA
    if ([string]::IsNullOrWhiteSpace($cacheBase)) { $cacheBase = [IO.Path]::GetTempPath() }
    $runtime = Join-Path $cacheBase 'LaCamaraDelMago/runtime'
    $null = [IO.Directory]::CreateDirectory($runtime)
    try {
        $setupLock = [IO.File]::Open((Join-Path $runtime 'setup.lock'), 'OpenOrCreate', 'ReadWrite', 'None')
    } catch [IO.IOException] { throw 'Otra ventana esta preparando el juego. Espera a que termine y vuelve a intentarlo.' }
    try {
        $phase = 'Preparar Node.js'
        $node = Get-Command node.exe -ErrorAction SilentlyContinue
        $npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
        $nodeCandidate = if ($node) { [IO.Path]::GetFullPath($node.Source) } else { $null }
        $npmCandidate = if ($npm) { [IO.Path]::GetFullPath($npm.Source) } else { $null }
        if ($nodeCandidate -and $npmCandidate -and (& $nodeCandidate --version) -match '^v(\d+)\.' -and [int]$Matches[1] -ge 24) {
            $nodePath = $nodeCandidate
            $npmPath = $npmCandidate
        } else {
            $nodeFolder = Install-GameNode $runtime
            $nodePath = Join-Path $nodeFolder 'node.exe'
            $npmPath = Join-Path $nodeFolder 'npm.cmd'
        }
        $env:PATH = "$(Split-Path -Parent $nodePath);$env:PATH"
        $phase = 'Instalar las dependencias del juego'
        $hasher = [Security.Cryptography.SHA256]::Create()
        try { $projectKey = [BitConverter]::ToString($hasher.ComputeHash([Text.Encoding]::UTF8.GetBytes($PSScriptRoot))).Replace('-', '').Substring(0, 16) }
        finally { $hasher.Dispose() }
        $pending = Join-Path $runtime ("npm-$projectKey.pending")
        if ((Test-Path -LiteralPath $pending) -or !(Test-Path -LiteralPath 'node_modules/pdfjs-dist/legacy/build/pdf.mjs' -PathType Leaf)) {
            Write-Host 'Instalando las dependencias del juego...'
            [IO.File]::WriteAllText($pending, '')
            & $npmPath ci --no-audit --no-fund
            if ($LASTEXITCODE -ne 0) { throw 'npm no pudo instalar las dependencias. Comprueba el mensaje anterior y vuelve a intentarlo.' }
            Remove-Item -LiteralPath $pending -Force
        }
    } finally { $setupLock.Dispose() }

    $phase = 'Iniciar el servidor del juego'
    $browserOption = @('--open-browser')
    if ($args -contains '--no-browser') { $browserOption = @() }
    & $nodePath server.mjs @browserOption @args
    exit $LASTEXITCODE
} catch {
    Write-Host ("No se pudo completar: " + $phase + '.') -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host 'Extrae el ZIP completo en una carpeta propia antes de ejecutar Jugar.cmd.'
    Write-Host 'Si Windows bloquea una carpeta o archivo, cierra las ventanas anteriores del juego y vuelve a intentarlo.'
    exit 1
}
