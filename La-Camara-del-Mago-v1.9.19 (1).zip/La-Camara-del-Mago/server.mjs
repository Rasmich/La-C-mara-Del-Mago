import { challengeType } from './public/ai-unit.mjs';
import { registerFailure, illustrationFor, ART_THEMES } from './public/encounters.mjs';
import { createServer } from 'node:http';
import { execFile } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { networkInterfaces } from 'node:os';
import { fileURLToPath } from 'node:url';
import { openClassroomStore } from './classroom-store.mjs';
import { demo, generarRetos, mezclar, normalizar } from './retos.mjs';

import { ROLES } from './roles.mjs';
import { makeBoard, createBoardState, boardView, moveTeam, rollMovement, afterSeal, challengeExit, retreatFromSanctuary, refillRollsWithLife, compassActive } from './board.mjs';

const defaultPort = 8787;
let port = Number(process.env.PORT || defaultPort);
const host = process.argv.includes('--local') ? '127.0.0.1' : '0.0.0.0';
const teacherKey = randomBytes(18).toString('base64url');
const rooms = new Map([['DEMO', { ...demo, teams: new Map() }]]);
const classroomStore = restoreClassrooms();
for (const [code, room] of classroomStore.rooms) rooms.set(code, room);
function restoreClassrooms() {
  const file = process.env.CAMARA_DATOS || fileURLToPath(new URL('./datos/partidas.sqlite', import.meta.url));
  try {
    return openClassroomStore(file);
  } catch (error) {
    console.error('No se pudieron abrir las partidas guardadas. Comprueba que el juego no esté abierto en otra ventana y que la carpeta datos permita escritura.');
    console.error(error.message);
    process.exit(1);
  }
}
const saveClock = setInterval(() => {
  try { classroomStore.tick(); }
  catch (error) { console.error('No se pudo guardar el reloj de las partidas:', error.message); }
}, 5000);
saveClock.unref();
const runes = ['Estrella', 'Luna', 'Montaña', 'Sol', 'Ola', 'Rayo', 'Llave', 'Ojo'];
const files = new Map([
  ['/marco-fuego.png', ['marco-fuego.png', 'image/png']],
  ['/marco-mago.png', ['marco-mago.png', 'image/png']],
  ['/brujo.png', ['brujo.png', 'image/png']],
  ['/encounters.mjs', ['encounters.mjs', 'text/javascript; charset=utf-8']],
  ['/desafios.png', ['desafios.png', 'image/png']],
  ['/gargola.webp', ['gargola.webp', 'image/webp']],
  ['/piedra-mapa.webp', ['piedra-mapa.webp', 'image/webp']],
  ...ROLES.map(({ id }) => {
    const name = `miniatura-${id}.webp`;
    return [`/${name}`, [name, 'image/webp']];
  }),
  ['/grenze-gotisch.ttf', ['grenze-gotisch.ttf', 'font/ttf']],
  ['/ignar.webp', ['ignar.webp', 'image/webp']],
  ['/dice-audio.mjs', ['dice-audio.mjs', 'text/javascript; charset=utf-8']],
  ['/die-3d.mjs', ['die-3d.mjs', 'text/javascript; charset=utf-8']],
  ['/board-ui.mjs', ['board-ui.mjs', 'text/javascript; charset=utf-8']],
  ['/ai-unit.mjs', ['ai-unit.mjs', 'text/javascript; charset=utf-8']],
  ['/roles.mjs', ['../roles.mjs', 'text/javascript; charset=utf-8']],
  ['/bolsa-cuero.png', ['bolsa-cuero.png', 'image/png']],
  ['/razas.png', ['razas.png', 'image/png']],
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/style.css', ['style.css', 'text/css; charset=utf-8']],
  ['/app.js', ['app.js', 'text/javascript; charset=utf-8']],
]);

class InputError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

function required(value, label, max) {
  if (typeof value !== 'string' || !value.trim() || value.length > max) {
    throw new InputError(`${label} debe tener entre 1 y ${max} caracteres.`);
  }
  return value.trim();
}

function validateSources(sources) {
  if (!Array.isArray(sources) || sources.length < 1 || sources.length > 9) {
    throw new InputError('Añade al menos un material. Puedes usar hasta ocho archivos y un texto pegado.');
  }
  let pdfSize = 0;
  const names = new Set();
  return sources.map(source => {
    const name = required(source?.name, 'El nombre del material', 180);
    if (names.has(name)) throw new InputError('Los materiales deben tener nombres distintos.');
    names.add(name);
    if (source.pdf != null) {
      const pdf = Buffer.from(required(source.pdf, 'El archivo PDF', 14_000_000), 'base64');
      if (!pdf.subarray(0, 1024).includes('%PDF-')) throw new InputError(`${name} no es un PDF válido.`);
      pdfSize += pdf.length;
      if (pdfSize > 24 * 1024 * 1024) throw new InputError('Los PDF superan 24 MB en total.');
      return { name, pdf };
    }
    return { name, text: required(source.text, 'El contenido de texto', 120_000) };
  });
}

async function readPages(source) {
  if (!source.pdf) return [source.text];
  let pdfjs;
  try {
    pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs');
  } catch (error) {
    console.error('PDF.js:', error.message);
    throw new InputError('Falta el lector de PDF. Ejecuta npm install en el ordenador docente.');
  }
  const options = {
    data: Uint8Array.from(source.pdf),
    isEvalSupported: false,
    cMapUrl: fileURLToPath(new URL('./node_modules/pdfjs-dist/cmaps/', import.meta.url)).replaceAll('\\', '/'),
    cMapPacked: true,
    standardFontDataUrl: fileURLToPath(new URL('./node_modules/pdfjs-dist/standard_fonts/', import.meta.url)).replaceAll('\\', '/'),
  };
  const task = pdfjs.getDocument(options);
  try {
    const document = await task.promise;
    if (document.numPages > 150) throw new InputError(`${source.name} supera las 150 páginas. Usa un extracto.`);
    const pages = [];
    for (let i = 1; i <= document.numPages; i++) {
      const page = await document.getPage(i);
      const content = await page.getTextContent();
      pages.push(content.items.map(item => `${item.str || ''}${item.hasEOL ? '\n' : ' '}`).join('').trim());
      page.cleanup();
    }
    return pages;
  } catch (error) {
    if (error instanceof InputError) throw error;
    throw new InputError(`No se pudo leer ${source.name}. Comprueba si está protegido o dañado.`);
  } finally {
    await task.destroy();
  }
}

function validateRoom(data) {
  const title = required(data.title, 'El título de la unidad', 100);
  const training = data.mode === 'training';
  const maxRolls = Number(data.maxRolls ?? 0);
  if (!Number.isSafeInteger(maxRolls) || maxRolls < 0) {
    throw new InputError('Indica un número entero de tiradas por sello. Usa 0 para jugar sin límite.');
  }
  const reward = required(data.reward || 'Habéis abierto la Cámara del Mago. Revisad vuestro cuaderno y compartid qué estrategia os ayudó más.', 'La recompensa', 2500);
  const minutes = Number(data.minutes);
  if (!Number.isInteger(minutes) || minutes < 1 || minutes > 120) {
    throw new InputError('La duración debe estar entre 1 y 120 minutos.');
  }
  const pairCount = Number(data.pairCount);
  if (!Number.isInteger(pairCount) || pairCount < 1 || pairCount > 60) {
    throw new InputError('Indica cuántas parejas jugarán, entre 1 y 60.');
  }
  const sources = validateSources(data.sources);
  if (!Array.isArray(data.challenges) || data.challenges.length < 3 || data.challenges.length > 8) {
    throw new InputError('La expedición necesita entre 3 y 8 retos.');
  }
  const challenges = data.challenges.map((challenge, index) => {
    const number = index + 1;
    const title = required(challenge?.title, `El nombre del reto ${number}`, 60);
    const prompt = required(challenge.prompt, `El enunciado del reto ${number}`, 4000);
    const hint = required(challenge.hint, `La pista del reto ${number}`, 500);
    if (!Array.isArray(challenge.answers) || (!challenge.answers.length && challenge.kind !== 'matching') || challenge.answers.length > 12) {
      throw new InputError(`Añade de 1 a 12 respuestas válidas para el reto ${number}.`);
    }
    if (!Array.isArray(challenge.options) || challenge.options.length === 1 || challenge.options.length > 8) {
      throw new InputError(`El reto ${number} debe tener de 2 a 8 opciones o un campo de respuesta abierta.`);
    }
    const answers = challenge.answers.map(value => normalizar(required(value, 'La respuesta', 350)));
    const options = challenge.options.map(value => required(value, 'La opción', 350));
    const optionKeys = options.map(normalizar);
    if (answers.some(value => !value) || optionKeys.some(value => !value) ||
      (options.length && (answers.length !== 1 || !optionKeys.some(value => answers.includes(value)) || new Set(optionKeys).size !== options.length))) {
      throw new InputError(`Revisa las respuestas y las opciones del reto ${number}. Debe haber una opción válida y las opciones han de ser distintas.`);
    }
    const strategy = challenge.strategy ? required(challenge.strategy, 'La primera pista', 500) : '';
    const explanation = challenge.explanation ? required(challenge.explanation, 'La solución razonada', 2500) : '';
    const reference = challenge.reference ? required(challenge.reference, 'La referencia docente', 500) : '';
    if(challenge.illustration!=null && !ART_THEMES.includes(challenge.illustration))throw new InputError('Ilustración de desafío no válida.');
    let type;
    try { type = challengeType({ ...challenge, answers, options }, 'Reto '+number+': '); }
    catch (error) { throw new InputError(error.message); }
    const meanings = type.pairs && mezclar(type.pairs.map(pair => pair.meaning));
    return { title, prompt, hint, strategy, answers, options, ...type, meanings, explanation, reference, illustration:challenge.illustration, reasoningRequired: challenge.reasoningRequired === true };
  });
  const passes = new Map();
  while (passes.size < pairCount) passes.set(randomBytes(5).toString('hex').toUpperCase(), null);
  return { title, reward, minutes, training, maxRolls, sources, challenges, teams: new Map(), passes };
}

function getRoom(code, allowPreview = false) {
  const room = rooms.get(String(code || '').trim().toUpperCase());
  if (!room) throw new InputError('No se encuentra esta sala. Comprueba el código y el ordenador donde se abrió.', 404);
  if (room.preview && !allowPreview) throw new InputError('La prueba se abre desde el ordenador docente.', 403);
  return room;
}

function newRoomCode() {
  let code;
  do { code = randomBytes(3).toString('hex').toUpperCase(); } while (rooms.has(code));
  return code;
}

function roomView(room) {
  return {
    title: room.title,
    minutes: room.minutes,
    training: Boolean(room.training),
    maxRolls: room.maxRolls ?? 0,
    board: { width: makeBoard(room.challenges.length).width },
    needsPass: Boolean(room.passes),
    preview: Boolean(room.preview),
    titles: room.challenges.map(item => item.title),
    sources: room.sources.map(({ name, text, pdf }) => ({ name, text, pdf: Boolean(pdf) })),
  };
}

function hintFor(challenge, level) {
  return level === 1
    ? challenge.strategy || 'Identificad qué os pide el sello. Comparad las dos interpretaciones más plausibles y buscad una evidencia que permita descartar una.'
    : challenge.hint;
}

function teamView(room, team) {
  const now = Date.now();
  const config = makeBoard(room.challenges.length);
  const board = boardView(team, config, room.maxRolls);
  const finished = team.finishedAt !== null;
  const dead = team.deadAt != null;
  const expired = !finished && !dead && now >= team.deadline;
  const atChest = !dead && !expired && !finished && board.phase === 'chest';
  const item = !dead && !expired && !finished && board.phase === 'challenge' ? room.challenges[team.step] : null;
  return {
    name: team.name, role: team.role, board, health: team.health ?? 3,
    step: team.step, now, deadline: team.deadline, finished, expired, dead,
    failures:team.challengeFailures[team.step] || 0, challengeFailures:[...team.challengeFailures],
    deathChallengeIndex:team.deathChallengeIndex, deathReason:team.deathReason, lastPenalty:team.lastPenalty, bossDefeated:team.bossDefeated,
    challenge: item && { title: item.title, prompt: item.prompt, options: item.options, kind: item.kind, terms: item.pairs?.map(pair => pair.term), meanings: item.meanings, reasoningRequired: item.reasoningRequired, illustration:illustrationFor(item,team.step,room.challenges.length), bossPhase: Math.max(0, team.step - room.challenges.length + 3) },
    revealedHint: item && team.hints[team.step] ? { level: team.hints[team.step], text: hintFor(item, team.hints[team.step]) } : undefined,
    fragments: team.fragments.slice(0, team.step),
    chestOrder: atChest ? team.chestOrder : undefined,
    retryAt: team.retryAt,
    reward: finished ? room.reward : undefined,
    journal: finished || dead || expired ? room.challenges.slice(0, Math.min(team.step + 1, room.challenges.length)).map((item, index) => ({
      title: item.title,
      mastered: index < team.step,
      misses: team.misses[index],
      hints: team.hints[index],
      explanation: index < team.step ? item.explanation : undefined,
      reference: index < team.step ? item.reference : undefined,
    })) : undefined,
  };
}

function getTeam(room, token) {
  const team = room.teams.get(token);
  if (!team) throw new InputError('No se encuentra vuestra partida. Volved a la entrada de la sala.', 404);
  return team;
}

async function jsonBody(req) {
  const limit = 36 * 1024 * 1024;
  if (!req.headers['content-type']?.startsWith('application/json')) throw new InputError('Formato de solicitud incorrecto.');
  if (Number(req.headers['content-length']) > limit) throw new InputError('La solicitud es demasiado grande.', 413);
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) throw new InputError('La solicitud es demasiado grande.', 413);
    chunks.push(chunk);
  }
  try {
    const data = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if (!data || Array.isArray(data) || typeof data !== 'object') throw new Error();
    return data;
  } catch {
    throw new InputError('La solicitud no contiene datos válidos.');
  }
}

function teacherRoomView(code, room) {
  return {
    code,
    addresses: host === '0.0.0.0' ? localAddresses() : [],
    passes: [...room.passes.keys()],
    previewAvailable: true,
  };
}

async function teacherAction(path, data) {
  if (path === 'check') {
    const activeRooms = [];
    for (const [code, room] of rooms) {
      if (room.passes) activeRooms.push({ code, title: room.title });
    }
    return { ok: true, rooms: activeRooms.reverse() };
  }
  if (path === 'room') {
    const code = String(data.code || '').trim().toUpperCase();
    const room = getRoom(code);
    if (!room.passes) throw new InputError('La demo se abre sin códigos de pareja.', 404);
    return teacherRoomView(code, room);
  }
  if (path === 'preview') {
    const room = getRoom(data.code);
    if (!room.passes) throw new InputError('Abre una sala de clase para probar sus retos.');
    const code = newRoomCode();
    if (room.previewCode) rooms.delete(room.previewCode);
    rooms.set(code, {
      title: room.title,
      minutes: room.minutes,
      training: room.training,
      maxRolls: room.maxRolls,
      sources: room.sources,
      challenges: room.challenges,
      reward: room.reward,
      teams: new Map(),
      preview: true,
    });
    room.previewCode = code;
    return { code };
  }
  if (path === 'generate') {
    const sources = validateSources(data.sources);
    const count = Number(data.count);
    if (!Number.isInteger(count) || count < 3 || count > 8) throw new InputError('Elige entre 3 y 8 retos.');
    const materials = [];
    for (const source of sources) materials.push({ ...source, pages: await readPages(source) });
    const challenges = generarRetos(materials, count);
    return {
      challenges,
      unreadable: materials.filter(source => !source.pages.some(page => page.trim())).map(source => source.name),
    };
  }
  if (path === 'publish') {
    const room = validateRoom(data);
    const code = newRoomCode();
    saveClassroom(() => classroomStore.saveRoom(code, room));
    rooms.set(code, room);
    return teacherRoomView(code, room);
  }
  if (path === 'teams') {
    const room = getRoom(data.code);
    const now = Date.now();
    return {
      teams: [...room.teams.values()].map(team => {
        return ({
        name: team.name,
        role: ROLES.find(role => role.id === team.role)?.name,
        progress: `${team.step}/${room.challenges.length}`,
        health: team.health ?? 3,
        position: team.board.position,
        moves: team.board.moves,
        incorrect: team.incorrect,
        challengeFailures: [...team.challengeFailures],
        reasoning: team.reasoning || [],
        hints: [...team.hints],
        misses: [...team.misses],
        state: team.deadAt != null ? ({
          trap: 'Personaje derrotado por una trampa',
          'roll-budget': 'Personaje derrotado al agotar la vida explorando',
        }[team.deathReason] ?? 'Personaje muerto por tres fallos')
          : team.finishedAt !== null ? 'Cofre abierto'
          : now >= team.deadline ? 'Tiempo agotado'
          : team.step === room.challenges.length ? (teamView(room, team).board.phase === 'chest' ? 'Ante el cofre' : 'Regresando al cofre')
          : teamView(room, team).board.phase === 'challenge' ? 'Resolviendo un desafío' : 'En el tablero',
      }); }),
    };
  }
  throw new InputError('Acción desconocida.', 404);
}

function saveClassroom(write) {
  try { write(); }
  catch (error) {
    console.error('No se pudo guardar el progreso:', error.message);
    throw new InputError('No se pudo guardar la partida. Avisad al docente y volved a intentarlo.', 503);
  }
}

function classicPenalty(team, room) {
  const count = room.challenges.length;
  const atChest = team.step === count;
  const exit = challengeExit(makeBoard(count), Math.min(team.step, count - 1));
  const penalty = registerFailure(team, exit, atChest ? 'chest' : 'challenge');
  if (penalty.kind === 'death') {
    return { penalty, feedback: 'Tercer fallo. Ignar ha derrotado a vuestro personaje. Fin de la partida.' };
  }
  const destination = penalty.number === 1 ? 'Salís de la sala.' : 'Volvéis a la casilla inicial.';
  const objective = atChest ? 'al cofre' : 'al mismo sello';
  return { penalty, feedback: `Fallo ${penalty.number} de 3. ${destination} Regresad ${objective} para reintentar.` };
}

function studentAction(path, data, allowPreview) {
  const code = String(data.code || '').trim().toUpperCase();
  const room = getRoom(code, allowPreview);
  if (path === 'room') return roomView(room);
  if (path === 'join') {
    let pass;
    if (room.passes) {
      pass = typeof data.pass === 'string' ? data.pass.replace(/[-\s]/g, '').toUpperCase() : '';
      if (!room.passes.has(pass)) throw new InputError('El código de pareja no es válido para esta sala.');
      const existing = room.passes.get(pass);
      if (existing) return { token: existing, state: teamView(room, getTeam(room, existing)) };
    }
    const name = required(data.name, 'El nombre de la pareja', 48);
    const role = data.role;
    if (!ROLES.some(item => item.id === role)) throw new InputError('Elegid una raza para vuestra pareja.');
    if (room.teams.size >= 2000) throw new InputError('La sala ha alcanzado su límite de partidas.');
    const token = randomBytes(24).toString('base64url');
    const order = mezclar(runes).slice(0, room.challenges.length);
    const digits = mezclar([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    const fragments = order.map((rune, index) => ({ rune, digit: digits[index] }));
    const chestOrder = mezclar(order);
    if (chestOrder.every((rune, index) => rune === order[index])) chestOrder.push(chestOrder.shift());
    const team = {
      name, role, board: createBoardState(), fragments, chestOrder, step: 0, deadline: Date.now() + room.minutes * 60_000,
      hints: Array(room.challenges.length).fill(0), misses: Array(room.challenges.length).fill(0),
      finishedAt: null, retryAt: 0, incorrect: 0, challengeFailures:Array(room.challenges.length).fill(0), health:3, deadAt:null, deathReason:null, deathChallengeIndex:null, lastPenalty:null, bossDefeated:false,
    };
    if (room.passes) saveClassroom(() => classroomStore.saveTeam(code, token, team, pass));
    room.teams.set(token, team);
    if (room.passes) room.passes.set(pass, token);
    return { token, state: teamView(room, team) };
  }
  const original = getTeam(room, data.token);
  const state = teamView(room, original);
  if (path === 'status' || state.dead || state.expired || state.finished) return { state };
  if (data.step !== original.step) return { state };
  // Publicamos el turno en memoria solo cuando se ha escrito en disco.
  const team = room.passes ? structuredClone(original) : original;
  function commitProgress(extra) {
    if (room.passes) {
      saveClassroom(() => classroomStore.saveTeam(code, data.token, team));
      room.teams.set(data.token, team);
    }
    return { state: teamView(room, team), ...extra };
  }
  if (path === 'consume') {
    const item = data.answer;
    if (data.revision !== team.board.revision) return { state };
    if (typeof item !== 'string' || !Object.hasOwn(team.board.inventory,item) || !team.board.inventory[item]) throw new InputError('Ese objeto no está en vuestro inventario.');
    if (item === 'amuleto' && team.board.shieldArmed) throw new InputError('Ya tenéis un amuleto activo.');
    if (item === 'brujula' && compassActive(team.board)) throw new InputError('Ya tenéis una brújula activa para este movimiento.');
    if (item === 'pocion' && team.health >= 3 && !team.challengeFailures[team.step]) throw new InputError('La poción solo puede recuperar vida o borrar un fallo del desafío actual.');
    if (item === 'pergamino' && !state.challenge) throw new InputError('El pergamino solo se puede usar dentro de un reto.');
    if (item === 'pergamino' && (team.hints[team.step] ?? 0) >= 2) throw new InputError('Ya habéis recibido las dos pistas de este sello.');
    team.board.inventory[item]--;
    team.board.revision++;
    let feedback;
    switch (item) {
      case 'amuleto':
        team.board.shieldArmed = true;
        feedback = 'Amuleto activo para la próxima trampa.';
        break;
      case 'reloj':
        team.deadline += 45_000;
        feedback = 'Reloj consumido: ganáis 45 segundos.';
        break;
      case 'pocion':
        if (team.health < 3) {
          team.health++;
          feedback = `Poción consumida: recuperáis 1 punto de vida (${team.health}/3).`;
        } else {
          team.challengeFailures[team.step]--;
          feedback = 'Poción consumida: borráis un fallo del desafío actual.';
        }
        break;
      case 'brujula':
        team.board.compassArmed = true;
        feedback = 'Brújula activa: +3 pasos en el próximo movimiento.';
        break;
      case 'pergamino': {
        const level = team.hints[team.step] = Math.min(2, (team.hints[team.step] ?? 0) + 1);
        feedback = `Pergamino usado: se revela la pista ${level} de 2.`;
        break;
      }
    }
    return commitProgress({ feedback });
  }
  if (path === 'roll') {
    if (data.revision !== team.board.revision || state.board.phase !== 'travel') return { state };
    if (state.board.remainingRolls === 0) return { state, feedback: 'Ya habéis usado todas las tiradas de este sello.' };
    const result = rollMovement(team, makeBoard(room.challenges.length), undefined, room.maxRolls);
    if (!result) return { state, feedback: 'Terminad el movimiento pendiente antes de volver a tirar.' };
    team.lastPenalty = null;
    const unit = result.movement === 1 ? 'paso' : 'pasos';
    const feedback = `El dado marca ${result.die}. Podéis avanzar hasta ${result.movement} ${unit}.${result.passive ? ` ${result.passive}` : ''}`;
    return commitProgress({ ...result, feedback });
  }
  if (path === 'move') {
    if (data.revision !== team.board.revision || state.board.phase !== 'travel') return { state };
    const allowLifeCost = data.allowLifeCost === true;
    if (state.board.lifeCostSquares.includes(data.answer) && !allowLifeCost) {
      throw new InputError('Confirmad que queréis gastar un punto de vida para explorar con la última tirada.');
    }
    const result = moveTeam(team, makeBoard(room.challenges.length), data.answer, room.maxRolls, allowLifeCost);
    if (!result) throw new InputError('Elegid una casilla alcanzable desde vuestra posición.');
    if (!state.board.reentry || !result.damage) team.lastPenalty = null;
    return commitProgress(result);
  }
  if (path === 'refill-rolls') {
    if (data.revision !== team.board.revision || !state.board.refillRequired || data.allowLifeCost !== true) return { state };
    const feedback = refillRollsWithLife(team);
    team.board.revision++;
    return commitProgress({ feedback });
  }
  if (path === 'unlock') {
    if (!state.chestOrder || data.revision !== team.board.revision) return { state };
    if (Date.now() < team.retryAt) return { state, feedback: 'Esperad unos segundos antes de volver a intentarlo.' };
    const combination = required(data.answer, 'La combinación', 30).replace(/\s/g, '');
    if (!new RegExp(`^\\d{${team.fragments.length}}$`).test(combination)) {
      throw new InputError(`Introducid exactamente ${team.fragments.length} cifras.`);
    }
    const expected = team.chestOrder.map(rune => team.fragments.find(fragment => fragment.rune === rune).digit).join('');
    if (combination !== expected) {
      if (!room.training) return commitProgress(classicPenalty(team, room));
      team.incorrect++;
      team.retryAt = Date.now() + 4000;
      retreatFromSanctuary(team, makeBoard(room.challenges.length));
      return commitProgress({ feedback: 'La combinación es incorrecta. Habéis salido del Santuario. Volved al cofre para intentarlo de nuevo.' });
    }
    team.finishedAt = Date.now();
    team.retryAt = 0;
    return commitProgress();
  }
  if (!state.challenge) return { state, feedback: 'Moveos por el mapa para llegar al siguiente desafío.' };
  const challenge = room.challenges[team.step];
  if (path === 'hint') {
    if (data.revision !== team.board.revision) return { state };
    const level = team.hints[team.step] = Math.min(2, team.hints[team.step] + 1);
    return commitProgress({ hint: hintFor(challenge, level), hintLevel: level });
  }
  if (path === 'answer') {
    if (data.revision !== team.board.revision) return { state };
    if (Date.now() < team.retryAt) return { state, feedback: 'Esperad unos segundos antes de volver a intentarlo.' };
    const reasoning = challenge.reasoningRequired ? required(data.reasoning, 'La justificación', 1500) : '';
    if (challenge.reasoningRequired && reasoning.length < 60) throw new InputError('Explicad vuestra decisión con al menos 60 caracteres e incluid una corrección y un ejemplo.');
    let correct;
    if (challenge.kind === 'matching') {
      if (!Array.isArray(data.answer) || data.answer.length !== challenge.pairs.length ||
          (new Set(data.answer).size !== data.answer.length || data.answer.some(value => !challenge.meanings.includes(value)))) throw new InputError('Relacionad todos los términos antes de responder.');
      correct = challenge.pairs.every((pair, index) => pair.meaning === data.answer[index]);
    } else {
      const answer = normalizar(required(data.answer, 'La respuesta', 350));
      correct = challenge.answers.some(value => normalizar(value) === answer);
    }
    if (!correct) {
      team.misses[team.step]++;
      if (room.training) {
        team.incorrect++;
        team.retryAt = Date.now() + 1500;
        if (team.step === room.challenges.length - 1) {
          retreatFromSanctuary(team, makeBoard(room.challenges.length));
          return commitProgress({ feedback: 'Ignar os expulsa del Santuario. Regresad al último sello para volver a intentarlo.' });
        }
        team.board.revision++;
        return commitProgress({ feedback: 'El sello sigue cerrado. Revisad la evidencia o pedid una pista antes de volver a intentarlo.' });
      }
      return commitProgress(classicPenalty(team, room));
    }
    if (reasoning) {
      team.reasoning ??= [];
      team.reasoning.push({ title: challenge.title, text: reasoning });
    }
    const bossJustDefeated=team.step===room.challenges.length-1;
    if(bossJustDefeated)team.bossDefeated=true;
    team.lastPenalty=null;
    team.step++;
    team.board.checkpoint = team.board.position;
    team.board.revision++;
    team.retryAt = 0;
    const racialBonus = afterSeal(team, room.challenges.length);
    const feedback = (bossJustDefeated ? '¡Habéis derrotado a Ignar! Ya podéis descifrar el cofre.' : 'Sello abierto. Habéis recuperado una runa.') + (racialBonus ? ` ${racialBonus}` : '');
    return commitProgress({ feedback });
  }
  throw new InputError('Acción desconocida.', 404);
}

function localAddresses() {
  return Object.values(networkInterfaces()).flat().filter(entry => entry.family === 'IPv4' && !entry.internal)
    .map(entry => `http://${entry.address}:${port}`);
}

function isTeacherComputer(req) {
  return ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress) &&
    [`localhost:${port}`, `127.0.0.1:${port}`].includes(req.headers.host?.toLowerCase());
}

const server = createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Content-Security-Policy', "default-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
  function json(data, status = 200) {
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify(data));
  }
  try {
    if (req.method === 'GET' && url.pathname === '/docente') {
      if (!isTeacherComputer(req)) throw new InputError('Abre el modo docente en el ordenador que ejecuta el juego.', 403);
      res.writeHead(303, { Location: `/#docente=${teacherKey}` });
      res.end();
      return;
    }
    const file = files.get(url.pathname);
    if (req.method === 'GET' && file) {
      const [name, type] = file;
      const content = await readFile(new URL(`./public/${name}`, import.meta.url));
      res.writeHead(200, { 'Content-Type': type });
      res.end(content);
      return;
    }
    const material = url.pathname.match(/^\/material\/([A-Z0-9]+)\/(\d+)$/);
    if (req.method === 'GET' && material) {
      const source = getRoom(material[1], isTeacherComputer(req)).sources[Number(material[2])];
      if (!source?.pdf) throw new InputError('El PDF no está disponible.', 404);
      res.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Length': source.pdf.length });
      res.end(source.pdf);
      return;
    }
    if (req.method === 'POST' && url.pathname.startsWith('/api/teacher/')) {
      if (!isTeacherComputer(req)) {
        throw new InputError('Abre el enlace del modo docente en el ordenador que ejecuta el juego.', 403);
      }
      if (req.headers['x-teacher-key'] !== teacherKey) throw new InputError('La clave docente no es válida.', 403);
      json(await teacherAction(url.pathname.slice(13), await jsonBody(req)));
      return;
    }
    if (req.method === 'POST' && url.pathname.startsWith('/api/play/')) {
      json(studentAction(url.pathname.slice(10), await jsonBody(req), isTeacherComputer(req)));
      return;
    }
    throw new InputError('Página no encontrada.', 404);
  } catch (error) {
    if (res.headersSent) { res.end(); return; }
    if (!(error instanceof InputError)) console.error(error);
    json({ error: error instanceof InputError ? error.message : 'El servidor no pudo completar la operación.' }, error.status || 500);
  }
});

server.on('error', error => {
  if (error.code === 'EADDRINUSE' && !process.env.PORT && process.argv.includes('--open-browser') && port < defaultPort+15) {
    port++;
    server.listen(port, host);
    return;
  }
  console.error(error.code === 'EADDRINUSE'
    ? `Ya hay un servidor en el puerto ${port}. Usa su ventana o ciérrala para arrancar esta versión.`
    : error.message);
  process.exitCode = 1;
});

server.once('listening', () => {
  console.log('\n  LA CÁMARA DEL MAGO · v1.9.19\n');
  console.log(`  En este ordenador: http://localhost:${port}`);
  console.log(`  Acceso docente:    http://localhost:${port}/docente`);
  if (host === '0.0.0.0') for (const address of localAddresses()) console.log(`  Red del aula:      ${address}`);
  console.log('  Deja esta ventana abierta durante la partida.\n');
  if (process.platform === 'win32' && process.argv.includes('--open-browser')) {
    const address = `http://127.0.0.1:${port}/`;
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Start-Process '${address}'`],
      { windowsHide: true }, error => {
        if (error) console.log(`  Abre el juego en el navegador: ${address}`);
      });
  }
});

server.listen(port, host);

function closeServer() {
  clearInterval(saveClock);
  server.close(() => {
    try { classroomStore.tick(); }
    catch (error) { console.error('No se pudo guardar el último instante del reloj:', error.message); }
    classroomStore.close();
  });
}
process.once('SIGINT', closeServer);
process.once('SIGTERM', closeServer);
