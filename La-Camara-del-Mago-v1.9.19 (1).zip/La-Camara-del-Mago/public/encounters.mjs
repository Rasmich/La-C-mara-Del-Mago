export const ART_THEMES = ['archivo','sendas','portales','alianza','taller','canales','reloj','tesoro','dragon'];
export const ART_LABELS = {
 archivo:'Archivo mágico y constructos animados',sendas:'Sendas luminosas entre torres',
 portales:'Portales de piedra y relojes de arena',alianza:'Aventureros ante un mapa compartido',
 taller:'Taller de engranajes y planos',canales:'Torres que intercambian mensajes',
 reloj:'Guardián y reloj de arena',tesoro:'Cofre del santuario',dragon:'Ignar, dragón rojo de la fortaleza',
};
export function illustrationFor(challenge,index,count) {
 if(index>=count-2)return 'dragon';
 if(ART_THEMES.includes(challenge.illustration))return challenge.illustration;
 const text=(challenge.title+' '+challenge.prompt).normalize('NFD').replace(/\p{M}/gu,'').toLowerCase();
 if(/hilos?|mapa|compartid|equipo.*colabor|alianza/.test(text))return 'alianza';
 if(/entrada estandar|salida estandar|tuberia|canal|comunica|mensaje|flush|stdin|stdout|eof/.test(text))return 'canales';
 if(/waitfor|plazo|tiempo.*espera|cronomet|cancel|exitvalue/.test(text))return 'reloj';
 if(/argument|directorio|entorno|processbuilder|configur|engranaje|constru/.test(text))return 'taller';
 if(/estado|bloquead|contador de programa|registros|pcb|portales/.test(text))return 'portales';
 if(/nucleos?|paralel|concurr|distribu|rutas?|camino|red/.test(text))return 'sendas';
 if(/archivo|inventario|ejecutable|instancia|biblioteca|document/.test(text))return 'archivo';
 return ART_THEMES[index%7];
}
export function registerFailure(team, exitSquare, reason = 'challenge', now = Date.now()) {
  if (team.deadAt != null || team.finishedAt != null) return null;
  team.challengeFailures ??= [];
  const number = (team.challengeFailures[team.step] ?? 0) + 1;
  team.challengeFailures[team.step] = number;
  team.incorrect++;
  team.board.revision++;
  team.retryAt = 0;

  const from = team.board.position;
  if (number >= 3) {
    team.deadAt = now;
    team.deathReason = reason;
    team.deathChallengeIndex = team.step;
  } else {
    team.board.position = number === 1 ? exitSquare : team.board.entrance;
  }
  team.lastPenalty = {
    kind: number >= 3 ? 'death' : 'retreat',
    challengeIndex: team.step,
    number,
    from,
    to: team.board.position,
    at: now,
  };
  return team.lastPenalty;
}
