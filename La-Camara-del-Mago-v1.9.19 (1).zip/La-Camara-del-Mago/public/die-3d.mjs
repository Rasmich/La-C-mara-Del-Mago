const WIDTH = 220;
const HEIGHT = 200;
const CAMERA = 7;
const SCALE = 75;
const ROLL_DURATION = 850;
const IDLE_FACE = 2;

const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [
  a[1] * b[2] - a[2] * b[1],
  a[2] * b[0] - a[0] * b[2],
  a[0] * b[1] - a[1] * b[0],
];
const subtract = (a, b) => a.map((component, index) => component - b[index]);
const offset = (point, vector, distance) => point.map((component, index) => component + vector[index] * distance);
const unit = v => v.map(component => component / Math.hypot(...v));
const average = points => points[0].map((_, index) =>
  points.reduce((sum, point) => sum + point[index], 0) / points.length);

function cyclicCoordinates([x, y, z]) {
  return [[x, y, z], [z, x, y], [y, z, x]];
}

function makeDie() {
  // Los vértices del dodecaedro regular se construyen con la proporción áurea.
  const phi = (1 + Math.sqrt(5)) / 2;
  const signs = [-1, 1];
  const coords = [];
  for (const a of signs) {
    for (const b of signs) {
      for (const c of signs) coords.push([a, b, c]);
      coords.push(...cyclicCoordinates([0, a / phi, b * phi]));
    }
  }
  const points = coords.map(point => point.map(value => value / Math.sqrt(3)));
  // Las normales provienen del icosaedro dual. Las caras opuestas suman 13.
  const firstHalf = signs.flatMap(sign => cyclicCoordinates([0, phi, sign])).map(unit);
  const oppositeHalf = firstHalf.slice().reverse().map(normal => normal.map(value => -value));
  return [...firstHalf, ...oppositeHalf].map((normal, index) => {
    const distance = Math.max(...points.map(point => dot(point, normal)));
    const pentagon = points.filter(point => Math.abs(dot(point, normal) - distance) < 1e-8);
    const center = average(pentagon);
    const right = unit(cross([0, 0, 1], normal));
    const up = cross(normal, right);
    const angle = point => {
      const direction = subtract(point, center);
      return Math.atan2(dot(direction, up), dot(direction, right));
    };
    pentagon.sort((a, b) => angle(a) - angle(b));
    return { points: pentagon, center, normal, right, up, number: index + 1 };
  });
}

const faces = makeDie();
const vertices = [...new Set(faces.flatMap(face => face.points))];
const elevation = 43 * Math.PI / 180;
const tableUp = [0, Math.cos(elevation), Math.sin(elevation)];
const digitUp = cross(tableUp, [1, 0, 0]);
const light = unit([-0.55, 0.72, 0.85]);
const rollAxis = unit([0.94, 0.28, -0.24]);

function poseFor(number) {
  const face = faces[number - 1];
  // Coloca la cara del resultado en horizontal y su cifra orientada al jugador.
  return point => offset(offset([dot(point, face.right), 0, 0], digitUp, dot(point, face.up)),
    tableUp, dot(point, face.normal));
}

function rotate(point, axis, angle) {
  const cosine = Math.cos(angle);
  const sine = Math.sin(angle);
  const tangent = cross(axis, point);
  const parallel = dot(axis, point) * (1 - cosine);
  return point.map((component, index) => component * cosine + tangent[index] * sine + axis[index] * parallel);
}

function turnBetween(start, end) {
  const normalCross = cross(start.normal, end.normal);
  const sine = Math.hypot(...normalCross);
  const tiltAxis = sine > 1e-8 ? unit(normalCross) : start.right;
  const tilt = Math.atan2(sine, dot(start.normal, end.normal));
  const rightAfterTilt = rotate(start.right, tiltAxis, tilt);
  const twist = Math.atan2(dot(cross(rightAfterTilt, end.right), end.normal), dot(rightAfterTilt, end.right));
  return (point, fraction) =>
    rotate(rotate(point, tiltAxis, tilt * fraction), end.normal, twist * fraction);
}

function project(point) {
  const perspective = SCALE * CAMERA / (CAMERA - point[2]);
  return [point[0] * perspective, -point[1] * perspective];
}

function outline(ctx, points) {
  ctx.beginPath();
  for (const [index, [x, y]] of points.entries()) {
    if (index === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
}

function drawDie(ctx, pose, hop = 0, drift = 0) {
  const floor = Math.max(...vertices.map(vertex => project(pose(vertex))[1]));
  const screen = point => {
    const [x, y] = project(point);
    return [WIDTH / 2 + x + drift, 174 + y - floor - hop];
  };

  ctx.clearRect(0, 0, WIDTH, HEIGHT);
  ctx.lineJoin = 'round';
  for (const face of faces) {
    const normal = pose(face.normal);
    const center = pose(face.center);
    // La cámara solo puede ver las caras que miran hacia ella.
    if (dot(normal, subtract([0, 0, CAMERA], center)) <= 0) continue;
    const corners = face.points.map(point => screen(pose(point)));
    const [x, y] = screen(center);
    const diffuse = Math.max(0, dot(normal, light));
    const lightness = 41 + 44 * diffuse;
    const glaze = ctx.createLinearGradient(x - 36, y - 41, x + 29, y + 38);
    glaze.addColorStop(0, `hsl(42 50% ${Math.min(93, lightness + 12)}%)`);
    glaze.addColorStop(0.52, `hsl(36 41% ${lightness}%)`);
    glaze.addColorStop(1, `hsl(29 36% ${lightness - 10}%)`);

    outline(ctx, corners);
    ctx.fillStyle = glaze;
    ctx.fill();
    ctx.strokeStyle = '#6b4730';
    ctx.lineWidth = 1.05;
    ctx.stroke();

    ctx.save();
    ctx.clip();
    // El relieve fino y la luz lateral dan el acabado de marfil tallado.
    outline(ctx, corners.map(([px, py]) => [x + 0.94 * (px - x), y + 0.94 * (py - y)]));
    ctx.strokeStyle = diffuse > 0.55 ? '#fff2dbaa' : '#efc59250';
    ctx.lineWidth = 1;
    ctx.stroke();

    const [rx, ry] = screen(offset(center, pose(face.right), 0.10));
    const [ux, uy] = screen(offset(center, pose(face.up), 0.10));
    ctx.transform((rx - x) / 8, (ry - y) / 8, (x - ux) / 8, (y - uy) / 8, x, y);
    ctx.font = face.number >= 10 ? 'bold 30px Georgia, serif' : 'bold 33px Georgia, serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = diffuse < 0.22 ? '#24140f' : '#392318';
    ctx.shadowColor = '#ffe5bba8';
    ctx.shadowOffsetY = 1;
    ctx.fillText(face.number, 0, 1);
    if (face.number === 6 || face.number === 9) ctx.fillRect(-6, 15, 12, 1.7);
    ctx.restore();
  }
}

function contextFor(canvas) {
  const ctx = canvas?.getContext('2d');
  ctx?.setTransform(canvas.width / WIDTH, 0, 0, canvas.height / HEIGHT, 0, 0);
  return ctx;
}

export function paintDie(canvas, number) {
  const ctx = contextFor(canvas);
  if (ctx) drawDie(ctx, poseFor(number ?? IDLE_FACE));
}

export function animateDie(canvas, number) {
  const ctx = contextFor(canvas);
  if (!ctx) return;
  const targetPose = poseFor(number);
  if (document.hidden || matchMedia('(prefers-reduced-motion: reduce)').matches) {
    drawDie(ctx, targetPose);
    return;
  }

  return new Promise(resolve => {
    let frameId;
    const start = performance.now();
    const turn = turnBetween(faces[IDLE_FACE - 1], faces[number - 1]);
    const finish = () => {
      clearTimeout(watchdog);
      cancelAnimationFrame(frameId);
      if (canvas.isConnected) drawDie(ctx, targetPose);
      resolve();
    };
    const watchdog = setTimeout(finish, ROLL_DURATION + 100);

    function frame(now) {
      if (!canvas.isConnected || now - start >= ROLL_DURATION) {
        finish();
        return;
      }
      const t = (now - start) / ROLL_DURATION;
      const revolution = 1 - (1 - t) ** 1.85;
      const angle = 4 * Math.PI * revolution;
      const hop = 18 * Math.abs(Math.sin(2 * Math.PI * t)) * (1 - t) + 4 * Math.sin(Math.PI * t);
      const drift = 10 * Math.sin(Math.PI * t) * Math.cos(2 * Math.PI * t);
      const pose = point => rotate(targetPose(turn(point, 1 - t)), rollAxis, angle);
      drawDie(ctx, pose, hop, drift);
      frameId = requestAnimationFrame(frame);
    }
    frameId = requestAnimationFrame(frame);
  });
}
