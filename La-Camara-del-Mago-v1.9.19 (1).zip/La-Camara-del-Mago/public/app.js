import { ART_THEMES, ART_LABELS } from '/encounters.mjs';
import { GameAudio } from '/dice-audio.mjs';
import { paintDie, animateDie } from '/die-3d.mjs';
import { ITEMS, boardMarkup, roomIllustrationMarkup } from '/board-ui.mjs';
import { CHALLENGE_TYPES, validateAiUnit, parseJsonFile, buildAiInstructions } from '/ai-unit.mjs';
import { ROLES } from '/roles.mjs';
const $ = id => document.getElementById(id);
$('launch-help').hidden = true;
const icon = name => `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;
const escape = value => String(value ?? '').replace(/[&<>"']/g, character =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
const game = $('game');
const teacherMessage = $('teacher-message');
const localTeacherUrl = new URL('/docente', location.origin);
localTeacherUrl.hostname = '127.0.0.1';
$('local-teacher-link').href = localTeacherUrl.href;
let view = 'entry';
let room;
let roomCode;
let team;
let teamToken;
let syncedAt;
let timer;
let teacherKey = '';
let fileSources = [];
let challenges = [];
let materialsChanged = false;
let pendingAi = null;
let rolling = false;
let moving = false;
const diceAudio = new GameAudio(localStorage.getItem('camara-dados-silencio') === 'true');

function message(element, text = '', kind = '') {
  element.textContent = text;
  element.classList.remove('error', 'success');
  if (kind) element.classList.add(kind);
}

async function post(group, action, data = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (group === 'teacher') headers['X-Teacher-Key'] = teacherKey;
  let response;
  try {
    response = await fetch(`/api/${group}/${action}`, {
      method: 'POST', headers, body: JSON.stringify(data),
    });
  } catch {
    throw new Error('No hay conexión con el ordenador docente. Comprobad la red del aula.');
  }
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'No se pudo completar la acción.');
  return result;
}

async function run(button, action, onError) {
  if (button?.disabled) return;
  if (button) button.disabled = true;
  try { await action(); }
  catch (error) { onError(error.message); }
  finally { if (button) button.disabled = false; }
}

function show(next) {
  if (next !== 'game') diceAudio.stopMusic();
  view = next;
  clearInterval(timer);
  for (const id of ['entry', 'game', 'teacher']) $(id).hidden = id !== next;
  $('student-tab').toggleAttribute('aria-current', next !== 'teacher');
  $('teacher-tab').toggleAttribute('aria-current', next === 'teacher');
  if (next === 'teacher') $('teacher-tab').setAttribute('aria-current', 'page');
  else $('student-tab').setAttribute('aria-current', 'page');
  window.scrollTo(0, 0);
}

function exitRoom() {
  history.replaceState(null, '', '/');
  show('entry');
}

async function openRoom(code) {
  const normalized = code.trim().toUpperCase();
  if (/^[0-9A-F]{5}-?[0-9A-F]{5}$/.test(normalized)) {
    throw new Error('Ese es un código de pareja. Abre el enlace de tu sala o busca su código de 6 caracteres. Dentro de la sala podrás introducir el código de pareja.');
  }
  const nextRoom = await post('play', 'room', { code: normalized });
  const token = sessionStorage.getItem(`camara-pareja-${normalized}`);
  let state = null;
  if (token) {
    try {
      state = (await post('play', 'status', { code: normalized, token })).state;
    } catch (error) {
      if (!error.message.startsWith('No se encuentra vuestra partida')) throw error;
      sessionStorage.removeItem(`camara-pareja-${normalized}`);
    }
  }
  roomCode = normalized;
  room = nextRoom;
  teamToken = state ? token : null;
  setTeam(state);
  history.replaceState(null, '', `/?sala=${encodeURIComponent(roomCode)}`);
  show('game');
  renderGame();
  if (team?.challenge || team?.chestOrder) focusStage();
  else if (team && !team.finished && !team.expired && !team.dead) focusBoard();
}

function setTeam(state) {
  team = state;
  syncedAt = performance.now();
}

function wizard(text, withHint = false) {
  return `<div class="wizard">
    <span class="wizard-frame wizard-frame-small"><span class="wizard-frame-window"><img src="/brujo.png" alt=""></span></span>
    <div><strong>El Mago del Umbral</strong><p>${escape(text)}</p>
    ${withHint ? '<p class="hint" id="hint" role="status" hidden></p>' : ''}</div>
  </div>`;
}

const runeSymbols = { Estrella: '✦', Luna: '☾', Montaña: '▲', Sol: '☉', Ola: '≋', Rayo: 'ϟ', Llave: '⚿', Ojo: '◉' };

function runeMark(rune) {
  return `<span class="rune-mark" aria-hidden="true">${runeSymbols[rune]}</span><span>${escape(rune)}</span>`;
}

function chestArt(open = false) {
  return `<svg class="chest-art" viewBox="0 0 168 124" aria-hidden="true">
    <ellipse cx="84" cy="114" rx="62" ry="6" fill="#0e0a14" stroke="none"/>
    ${open ? '<g class="chest-lid"><path d="M26 54 37 26Q84 2 131 26l11 28Z" fill="#4d3247"/></g><path class="chest-light" d="M40 56h88M71 43l-8-12m21 10V25m13 18 8-12"/>' :
    '<path d="M23 68V56c0-22 18-39 40-39h42c22 0 40 17 40 39v12Z" fill="#4d3247"/><path d="M47 66V53c0-20 12-32 17-35m57 48V53c0-20-12-32-17-35"/>'}
    <path d="M23 66h122v39a7 7 0 0 1-7 7H30a7 7 0 0 1-7-7Z" fill="#38263d"/>
    <path d="M24 68h120m-120 31h120M47 70v40m74-40v40"/>
    <rect x="72" y="59" width="24" height="29" rx="5" fill="#c4915e" stroke="#efc28e"/>
    <circle cx="84" cy="70" r="3" fill="#2b1c2c" stroke="none"/><path d="M84 72v6" stroke="#2b1c2c"/>
  </svg>`;
}

function renderGame(feedback = '') {
  const started = Boolean(team);
  if (started && !team.finished && !team.dead && !team.expired) void diceAudio.startMusic();
  else diceAudio.stopMusic();
  const materials = room.sources.map((source, index) => source.pdf
    ? `<a class="material" href="/material/${encodeURIComponent(roomCode)}/${index}" target="_blank" rel="noopener">${escape(source.name)} <span class="muted">· PDF, nueva pestaña</span></a>`
    : `<details class="material"><summary>${escape(source.name)}</summary><p>${escape(source.text)}</p></details>`).join('');
  game.innerHTML = `
    <button type="button" class="back" id="back-room">← ${room.preview && teacherKey ? 'Volver al modo docente' : 'Volver al inicio'}</button>
    <header class="section-heading game-header">
      <div><p class="eyebrow"><span></span> ${room.preview ? 'PRUEBA DOCENTE' : `SALA ${escape(roomCode)}`}</p><h1>${escape(room.title)}</h1>
      <p class="lead">${started ? escape(team.name) : `${room.titles.length} sellos · ${room.minutes} minutos · 2 personas`}</p></div>
      ${started && !team.finished && !team.dead ? `<div class="clock" id="clock" role="timer" aria-label="Tiempo restante">${icon('clock')} <span id="clock-value"></span></div>` : ''}
    </header>
    <section class="panel board-panel" id="board-panel" hidden></section>
    <div class="game-layout">
      <section class="panel" id="game-stage"></section>
      <aside class="game-side">
        <section class="panel" id="rune-panel" hidden></section>
        <section class="panel"><p class="eyebrow">BIBLIOTECA DE LA SALA</p><h2>Vuestros materiales</h2><div class="materials">${materials}</div></section>
      </aside>
    </div>`;
  $('back-room').addEventListener('click', () => {
    exitRoom();
    if (room.preview && teacherKey) show('teacher');
  });
  renderStage(feedback);
  clearInterval(timer);
  if (started && !team.finished && !team.dead) {
    updateClock();
    if (!team.expired) timer = setInterval(updateClock, 250);
  }
}

function renderAdventure(options = {}) {
  const panel = $('board-panel');
  if (!panel || !team) return;
  panel.hidden = false;
  const bagOpen = panel.querySelector('.board-inventory')?.open ?? false;
  panel.innerHTML = boardMarkup(room.board, team, { soundOn: !diceAudio.muted, bagOpen, rolling, ...options });
  paintDie(panel.querySelector('.movement-die'), team.board.rollValue);
  for (const button of panel.querySelectorAll('[data-stage-link], .dungeon-tile.chest-available')) {
    button.addEventListener('click', focusStage);
  }
  for (const door of panel.querySelectorAll('[data-door-note]')) {
    door.addEventListener('click', () => {
      const feedback = $('door-feedback');
      feedback.textContent = door.dataset.doorNote;
      feedback.scrollIntoView({ block: 'nearest' });
    });
  }
  const moves = panel.querySelectorAll('[data-move-to], .dungeon-tile.reachable');
  for (const button of moves) {
    const destination = Number(button.dataset.moveTo ?? button.dataset.square);
    const preview = () => {
      if (!moving) showBoardPath(panel, team.board.paths[destination]);
    };
    const clearPreview = () => {
      if (!moving && !button.matches(':hover, :focus-visible')) showBoardPath(panel);
    };
    button.addEventListener('pointerenter', preview);
    button.addEventListener('pointerleave', clearPreview);
    button.addEventListener('focus', () => {
      if (button.matches(':focus-visible')) preview();
    });
    button.addEventListener('blur', clearPreview);
    button.addEventListener('click', async () => {
      if (moving || rolling) return;
      const path = team.board.paths[destination];
      if (!path) return;
      const token = teamToken;
      const revision = team.board.revision;
      const costsLife = team.board.lifeCostSquares.includes(destination);
      if (costsLife && !await confirmLifeCost()) return;
      if (view !== 'game' || teamToken !== token || team.board.revision !== revision) return;
      moving = true;
      for (const move of moves) move.disabled = true;
      showBoardPath(panel, path);
      $('move-feedback').textContent = `Avanzáis ${path.length} ${path.length === 1 ? 'paso' : 'pasos'}…`;
      let narration = '';
      try {
        await play('move', destination, undefined, costsLife);
      } catch (error) {
        narration = error.message;
      } finally {
        moving = false;
        if (view === 'game' && teamToken === token && team.board.revision === revision) {
          renderAdventure({ narration });
          panelFocusReachable();
        }
      }
    });
  }
  const rollButton = $('roll-dice');
  rollButton?.addEventListener('click', () => run(rollButton, rollDice, gameError));
  $('choose-exploration')?.addEventListener('click', () => {
    const destination = panel.querySelector('[data-life-cost]');
    destination?.focus({ preventScroll: true });
    destination?.scrollIntoView({ block: 'nearest' });
  });
  const refillButton = $('refill-rolls');
  refillButton?.addEventListener('click', () => run(refillButton, async () => {
    const token = teamToken;
    const revision = team.board.revision;
    if (await confirmLifeCost() && view === 'game' && teamToken === token && team.board.revision === revision) {
      await play('refill-rolls', undefined, undefined, true);
    }
  }, gameError));
  for (const button of panel.querySelectorAll('[data-consume]')) {
    button.addEventListener('click', () => {
      if (!moving) run(button, () => play('consume', button.dataset.consume), gameError);
    });
  }
  $('toggle-dice-sound').addEventListener('click', event => {
    diceAudio.setMuted(!diceAudio.muted);
    localStorage.setItem('camara-dados-silencio', String(diceAudio.muted));
    if (!diceAudio.muted && !team.dead && !team.finished && !team.expired) void diceAudio.unlock().then(() => { if (view === 'game' && team && !team.dead && !team.finished && !team.expired) void diceAudio.startMusic(); });
    event.currentTarget.setAttribute('aria-pressed', String(diceAudio.muted));
    event.currentTarget.textContent = diceAudio.muted ? 'Audio: silenciado' : 'Audio: activado';
  });
}

function showBoardPath(panel, path = []) {
  for (const tile of panel.querySelectorAll('.preview-path')) tile.classList.remove('preview-path');
  for (const square of path) panel.querySelector(`[data-square="${square}"]`)?.classList.add('preview-path');
}

async function confirmLifeCost() {
  const dialog = document.createElement('dialog');
  dialog.className = 'pickup-dialog';
  dialog.setAttribute('aria-labelledby', 'life-cost-heading');
  dialog.setAttribute('aria-describedby', 'life-cost-description');
  dialog.innerHTML = `<h2 id="life-cost-heading">Seguir explorando</h2>
    <p id="life-cost-description">${team.health === 1
      ? 'Gastar vuestra última vida termina la partida.'
      : 'Perderéis 1 punto de vida y recuperaréis las tiradas del sello.'}</p>
    <form method="dialog">
      <button class="button ghost" value="cancel" autofocus>Cancelar</button>
      <button class="button primary" value="explore">Gastar 1 vida</button>
    </form>`;
  document.body.append(dialog);
  try {
    const choice = new Promise(resolve => dialog.addEventListener('close', () => resolve(dialog.returnValue), { once: true }));
    dialog.showModal();
    return (await choice) === 'explore';
  } finally {
    dialog.remove();
  }
}

async function animateBoardMove(result) {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const grid = game.querySelector('.dungeon-grid');
  const origin = grid?.querySelector('.dungeon-tile.current');
  const piece = origin?.querySelector('.dungeon-token');
  if (!piece?.animate || !result.path?.length) return;

  // La ruta la confirma el servidor. Si hay una trampa, se ve también el retroceso.
  const squares = result.damage ? [...result.path, result.state.board.position] : result.path;
  const start = origin.getBoundingClientRect();
  const points = [{ x: 0, y: 0 }];
  for (const square of squares) {
    const tile = grid.querySelector(`[data-square="${square}"]`);
    if (!tile) break;
    const rect = tile.getBoundingClientRect();
    points.push({ x: rect.left - start.left, y: rect.top - start.top });
  }
  if (points.length < 2) return;

  const frame = (x, y) => ({ transform: `translate(${x}px, ${y}px)` });
  const frames = [frame(0, 0)];
  const hop = Math.min(6, start.height * .15);
  for (let index = 1; index < points.length; index++) {
    const before = points[index - 1];
    const after = points[index];
    frames.push(frame((before.x + after.x) / 2, (before.y + after.y) / 2 - hop));
    frames.push(frame(after.x, after.y));
  }

  origin.classList.add('moving-piece');
  const animation = piece.animate(frames, {
    duration: Math.min(620, 105 + (points.length - 1) * 65),
    fill: 'forwards',
  });
  await animation.finished.catch(() => {});
}

async function rollDice() {
  if (rolling || !team || team.board.phase !== 'travel' || team.board.remainingSteps > 0 || team.board.remainingRolls === 0) return;
  const token = teamToken;
  const code = roomCode;
  const step = team.step;
  const revision = team.board.revision;
  const sameTurn = () => view === 'game' && teamToken === token && team.step === step && team.board.revision === revision;
  let narration = '';
  rolling = true;
  void diceAudio.unlock();
  renderAdventure();
  try {
    const result = await post('play', 'roll', { code, token, step, revision });
    if (!sameTurn() || result.state.board.revision < revision) return;
    if (Number.isInteger(result.die)) {
      diceAudio.play();
      await animateDie(game.querySelector('.movement-die'), result.die);
      if (!sameTurn()) return;
    }
    setTeam(result.state);
    rolling = false;
    if (team.expired || team.dead || team.finished) renderGame();
    else renderAdventure({ narration: result.die === undefined ? result.feedback : '' });
    updateClock();
    panelFocusReachable();
  } catch (error) {
    narration = error.message;
  } finally {
    if (rolling) {
      rolling = false;
      if (view === 'game') {
        renderAdventure({ narration });
        panelFocusReachable();
      }
    }
  }
}

function panelFocusReachable() {
  const first = game.querySelector('[data-move-to]:not(:disabled), #roll-dice:not(:disabled), #refill-rolls:not(:disabled), [data-stage-link]') ||
    game.querySelector('.dungeon-tile.reachable:not(:disabled)');
  first?.focus({ preventScroll: true });
}

function focusBoard() {
  $('board-panel')?.scrollIntoView({ block: 'start' });
  panelFocusReachable();
}
async function showPickup(item) {
  diceAudio.cue('pickup');
  return showDiscovery({ ...ITEMS[item], label: 'Objeto conseguido', note: 'Añadido a la Bolsa.' });
}

async function showDiscovery({ name, symbol, description, label, note }) {
  const dialog = document.createElement('dialog');
  dialog.className = 'pickup-dialog';
  dialog.setAttribute('aria-labelledby', 'pickup-title');
  dialog.setAttribute('aria-describedby', 'pickup-description');
  dialog.innerHTML = `<p class="eyebrow">${escape(label)}</p>
    <span class="pickup-icon" aria-hidden="true">${symbol}</span>
    <h2 id="pickup-title">${escape(name)}</h2>
    <p id="pickup-description">${escape(description)}</p>
    ${note ? `<p class="muted">${escape(note)}</p>` : ''}
    <form method="dialog"><button class="button primary" autofocus>Continuar</button></form>`;
  document.body.append(dialog);
  try {
    const dismissed = new Promise(resolve => dialog.addEventListener('close', resolve, {once:true}));
    dialog.showModal();
    await dismissed;
  } finally {
    dialog.remove();
  }
}

async function showRoomDiscovery(room, doorName = '', challenge = null) {
  if (!room) {
    return showDiscovery({
      name: doorName || 'Sala descubierta', symbol: '🚪',
      description: 'La puerta cede y revela una estancia de la fortaleza.', label: 'Puerta abierta',
    });
  }
  diceAudio.cue('portal');
  const bossPhase = challenge?.bossPhase;
  const art = bossPhase ? `<div class="dragon-reveal" aria-hidden="true">
    <div class="dragon-reveal-scene">
      <img src="/ignar.webp" alt="" width="418" height="418">
      <span class="dragon-firelight"></span>
      <span class="dragon-breath"><span class="dragon-fire-stream"></span><i></i><i></i><i></i><i></i><i></i></span>
    </div>
  </div>` : roomIllustrationMarkup(room, 'room-reveal-art');
  const dialog = document.createElement('dialog');
  dialog.className = 'room-reveal-dialog';
  dialog.setAttribute('aria-labelledby', 'room-reveal-title');
  dialog.innerHTML = `${art}
    <div class="room-reveal-content"><p class="eyebrow">${bossPhase ? `IGNAR · FASE ${bossPhase} DE 2` : 'UMBRAL CRUZADO · SALA DESCUBIERTA'}</p>
      <h2 id="room-reveal-title">${escape(room.name || doorName || 'Nueva sala')}</h2>
      <p>${bossPhase ? 'Ignar lanza una llamarada. Resolved el sello para seguir avanzando.' : challenge ? 'Habéis cruzado la puerta. El sello os espera dentro.' : 'La puerta se abre y revela una nueva estancia.'}</p>
      <form method="dialog"><button class="button primary" autofocus>${challenge ? 'Ir al desafío' : 'Volver al mapa'}</button></form>
    </div>`;
  document.body.append(dialog);
  try {
    const dismissed = new Promise(resolve => dialog.addEventListener('close', resolve, { once: true }));
    dialog.showModal();
    await dismissed;
  } finally {
    dialog.remove();
  }
}

function encounterArt(theme, boss=false) {
  const index=Math.max(0,ART_THEMES.indexOf(theme)),x=index%3*100,y=Math.floor(index/3)*100;
  return '<figure class="encounter-art'+(boss?' boss-art':'')+'"><svg viewBox="'+x+' '+y+' 100 100" preserveAspectRatio="'+(boss?'xMidYMin slice':'xMidYMid slice')+'" role="img" aria-label="'+escape(ART_LABELS[theme]||ART_LABELS.archivo)+'"><image href="/desafios.png" x="0" y="0" width="300" height="300"/></svg><figcaption>'+(boss?'IGNAR · DRAGÓN DE LA FORTALEZA':escape(ART_LABELS[theme]||ART_LABELS.archivo))+'</figcaption></figure>';
}
function deathScene() {
  if (team.deathReason === 'roll-budget') {
    return `<section class="trap-death-scene" aria-label="Vida agotada al explorar">
      <div class="trap-death-art" aria-hidden="true"><span>♥</span><i></i></div>
      <div class="death-verdict"><p class="eyebrow">VIDA AGOTADA · EXPLORACIÓN</p><h2 id="stage-heading" tabindex="-1">GAME OVER</h2>
        <p class="death-cause">Habéis gastado vuestra última vida al seguir explorando.</p></div>
    </section>`;
  }
  if (team.deathReason === 'trap') {
    return `<section class="trap-death-scene" aria-label="La trampa agota la vida del personaje">
      <div class="trap-death-art" aria-hidden="true"><span>⚠</span><i></i></div>
      <div class="death-verdict"><p class="eyebrow">VIDA AGOTADA · TRAMPA</p><h2 id="stage-heading" tabindex="-1">GAME OVER</h2>
        <p class="death-cause">La trampa os ha derrotado.</p><p>Habéis perdido los tres puntos de vida. Esta partida ha terminado.</p></div>
    </section>`;
  }
  const cause = team.deathReason === 'chest'
    ? 'Habéis fallado tres veces la combinación del cofre.'
    : `Habéis fallado tres veces el desafío ${team.deathChallengeIndex + 1}.`;
  return `<section class="dragon-death-scene" aria-label="Ignar derrota al personaje">${encounterArt('dragon', true)}
    <div class="death-fire" aria-hidden="true"></div><div class="death-hero role-${team.role}" aria-hidden="true"><span class="role-art"></span><span class="death-skull">☠</span></div>
    <div class="death-verdict"><p class="eyebrow">TRES FALLOS · FIN DE LA PARTIDA</p><h2 id="stage-heading" tabindex="-1">GAME OVER</h2><p class="death-cause">Ignar os ha derrotado.</p><p>${cause}</p></div></section>`;
}
function healthMeter() {
  const health = Math.max(0, Math.min(3, team.health ?? 3));
  return `<div class="health-meter" role="status"><strong>Vida del personaje</strong><span class="health-hearts" aria-label="${health} de 3 puntos de vida">${'♥'.repeat(health)}${'♡'.repeat(3-health)}</span><span class="health-count">${health}/3 puntos</span></div>`;
}
function failureMeter() {
  if (room.training || team.dead || team.finished || team.expired) return '';
  const objective = team.step === room.titles.length ? 'el cofre' : 'este reto';
  return `<div class="failure-meter" role="status"><strong>Errores en ${objective}: ${team.failures}/3</strong><span>1.º: fuera de la sala · 2.º: casilla inicial · 3.º: derrota ante Ignar</span></div>`;
}
function showHint(level, text) {
  const hint = $('hint');
  hint.hidden = false;
  hint.textContent = `Pista ${level} de 2. ${text}`;
  $('hint-button').textContent = level === 1 ? 'Pedir una pista más concreta' : 'Volver a mostrar la pista';
}

function renderJournal() {
  if (!team.journal?.length) return '';
  return `<section class="review-journal" aria-labelledby="journal-title">
    <h3 id="journal-title">Cuaderno de expedición</h3>
    <p>Comparad vuestras estrategias. Elegid un sello y explicad a vuestra pareja cómo aplicaríais lo aprendido a un caso distinto.</p>
    ${team.journal.map(entry => `<details>
      <summary>${escape(entry.title)} · ${entry.mastered ? 'Superado' : 'Por revisar'}</summary>
      <p>Intentos fallidos: ${entry.misses} · Niveles de pista consultados: ${entry.hints}/2</p>
      ${entry.explanation ? `<p class="prompt">${escape(entry.explanation)}</p>` : ''}
      ${entry.reference ? `<p>Fuente: ${escape(entry.reference)}</p>` : ''}
      ${!entry.mastered ? '<p>¿Qué concepto os faltaba comprobar? Comentadlo con el docente.</p>' : ''}
    </details>`).join('')}
  </section>`;
}

function recoveredRunesMarkup() {
  return `<ul class="rune-list">${team.fragments.map(({ rune, digit }) => `<li>${runeMark(rune)}<strong>${digit}</strong></li>`).join('')}</ul>`;
}

function renderStage(feedback = '', boardOptions) {
  if (team) renderAdventure(boardOptions);
  const stage = $('game-stage');
  const challengeMode = Boolean(team?.challenge && !team.dead && !team.finished && !team.expired && !team.chestOrder);
  stage.classList.toggle('challenge-mode', challengeMode);
  game.classList.toggle('challenge-active', challengeMode);
  stage.closest('.game-layout')?.classList.toggle('challenge-active', challengeMode);
  const runePanel = $('rune-panel');
  runePanel.hidden = !team?.fragments.length || Boolean(team.chestOrder);
  if (!runePanel.hidden) {
    runePanel.innerHTML = `<p class="eyebrow">CUADERNO DE LA PAREJA</p><h2>Runas recuperadas</h2>${recoveredRunesMarkup()}`;
  }
  if (!team) {
    stage.innerHTML = `${wizard('Bienvenidos, aprendices. Cada sello guarda una prueba que solo podréis superar si trabajáis juntos.')}
      <h2 id="stage-heading" tabindex="-1">Las reglas del Mago</h2>
      <ol class="rules">
        <li>Formad una pareja. Una persona busca en los materiales y la otra propone la respuesta. Cambiad de papel tras cada sello.</li>
        <li>Consultad solo los PDF y apuntes de esta sala. Durante la partida, dejad abiertas únicamente las pestañas del juego y sus materiales. Si os atascáis, pedidle una pista al Mago.</li>
        ${room.needsPass ? '<li>El docente supervisará las pantallas durante la actividad. Usad solo el código privado asignado a vuestra pareja.</li>' : ''}
        <li>Tirad el dado y seguid la puerta resaltada. Podéis usar el botón de avance o elegir una casilla iluminada. Al cruzar la puerta del desafío, podréis empezar el reto. Cada sello superado os da una runa.</li>
        <li>Empezáis con 3 puntos de vida, independientes de los errores del reto. Algunas puertas esconden trampas que quitan un punto si no las bloqueáis. El amuleto y la pasiva enana protegen; la poción recupera vida. Con cero puntos, la partida termina.</li>
        ${room.maxRolls ? `<li>Tenéis hasta ${room.maxRolls} ${room.maxRolls === 1 ? 'tirada' : 'tiradas'} por sello. Con la última podéis entrar si el sello está al alcance. Terminar el movimiento fuera cuesta una vida.</li>` : ''}
        <li>${room.training ? 'Modo aula: podéis reintentar desde el mismo sello, salvo en el último. Si falláis en el Santuario, tendréis que volver a entrar.' : 'En cada desafío y en el cofre, el primer fallo os saca de la sala. El segundo os devuelve a la casilla inicial. Al tercero, Ignar os derrota. Si seguís en partida, podéis regresar y conservaréis las runas ganadas.'}</li>
        <li>Abrid las puertas para descubrir nuevas salas. Los dos últimos desafíos forman el encuentro con Ignar. Al descubrir el Santuario veréis el cofre cerrado; al superar el último reto, seleccionad su casilla para ir a la cerradura y ordenar las cifras. Tenéis ${room.minutes} minutos para abrirlo desde que pulsáis «Empezar expedición».</li>
      </ol>
      <form id="join-form">
        <fieldset class="role-picker"><legend>Elegid una raza para vuestra pareja</legend>
          <p class="muted">Una carta para los dos. Las habilidades actúan automáticamente sobre el tablero y tienen usos limitados. Ninguna revela soluciones ni permite saltarse un desafío. La elección queda fijada al empezar.</p>
          <div class="role-grid">${ROLES.map(role => `<label class="role-card role-${role.id}">
            <input type="radio" name="role" value="${role.id}" required>
            <span class="role-card-art">
              <span class="role-art" aria-hidden="true"></span>
              <img class="role-card-miniature" src="/miniatura-${role.id}.webp" alt="" draggable="false">
            </span>
            <span class="role-copy"><strong>${escape(role.name)}</strong><span class="role-ability">${escape(role.ability)}</span><span>${escape(role.description)}</span></span>
          </label>`).join('')}</div>
        </fieldset>
        <label>Nombre de la pareja<input name="name" maxlength="48" required placeholder="Ej. Los Guardianes"${room.preview ? ' value="Pareja de prueba"' : ''}></label>
        ${room.needsPass ? `<label class="pair-pass">Código privado de pareja<input name="pass" maxlength="15" required placeholder="Formato: XXXXX-XXXXX" autocomplete="off" spellcheck="false"><small>Ya estáis en la sala ${escape(roomCode)}. Aquí va el código de 10 caracteres que os da el docente.</small></label>` : ''}
        <div class="answer-actions"><button class="button primary">Empezar expedición ${icon('arrow')}</button></div>
      </form><p class="notice game-feedback" id="game-feedback" role="status"></p>`;
    $('join-form').addEventListener('submit', event => {
      event.preventDefault();
      const { name, pass, role } = Object.fromEntries(new FormData(event.currentTarget));
      run(event.submitter, async () => {
        const privateCode = pass?.replace(/[\s\p{Pd}]/gu, '').toUpperCase();
        if (room.needsPass && privateCode === roomCode) {
          throw new Error(`${roomCode} es el código de sala. Introducid el código privado de pareja que os dio el docente.`);
        }
        if (room.needsPass && !/^[0-9A-F]{10}$/.test(privateCode)) {
          throw new Error('Introducid los 10 caracteres del código privado de pareja. El guion es opcional.');
        }
        const audioReady = diceAudio.unlock();
        const result = await post('play', 'join', { code: roomCode, name, pass: privateCode, role });
        teamToken = result.token;
        sessionStorage.setItem(`camara-pareja-${roomCode}`, teamToken);
        setTeam(result.state);
        void audioReady.then(() => {
          if (view === 'game' && teamToken === result.token && !team.dead && !team.finished && !team.expired) {
            diceAudio.cue('start');
            void diceAudio.startMusic();
          }
        });
        renderGame();
        focusBoard();
      }, gameError);
    });
    return;
  }
  const track = room.titles.map((title, index) => {
    const done = index < team.step;
    const current = index === team.step && !team.expired && !team.dead;
    const status = done ? 'superado' : current ? 'actual' : 'pendiente';
    return `<li class="${done ? 'done' : current ? 'current' : ''}" title="${escape(title)}" aria-label="Sello ${index + 1} ${status}" ${current ? 'aria-current="step"' : ''}>${done ? icon('check') : index + 1}</li>`;
  }).join('');
  const chosenRole = ROLES.find(role => role.id === team.role);
  const roleStatus = chosenRole ? `<div class="role-status role-${chosenRole.id}" role="status"><span class="role-mini role-art" aria-hidden="true"></span><div><strong>${escape(chosenRole.name)} · ${escape(chosenRole.ability)}</strong><p>${escape(chosenRole.description)} Usos: ${team.board.passiveUsed}/${chosenRole.charges}.${team.board.passiveLog ? ' ' + escape(team.board.passiveLog) : ''}</p></div></div>` : '';
  const failureBadge = failureMeter();
  const progress = roleStatus + healthMeter() + failureBadge + `<p class="eyebrow">${team.step} DE ${room.titles.length} SELLOS SUPERADOS</p><ol class="track" aria-label="Progreso">${track}</ol>`;
  if(team.dead){
    stage.innerHTML=progress+deathScene()+renderJournal();
    return;
  }
  if (team.finished || team.expired) {
    stage.innerHTML = progress + (team.finished
      ? `${wizard('Habéis descifrado la combinación. Aquí tenéis vuestra recompensa.')}<div class="chest-illustration">${chestArt(true)}</div><h2 id="stage-heading" tabindex="-1">El cofre está abierto</h2><section class="reward chest-reward" aria-labelledby="reward-heading" role="status"><h3 id="reward-heading">Vuestra recompensa</h3><p>${escape(team.reward || "El docente no ha indicado una recompensa.")}</p></section>`
      : `${wizard('La última chispa se ha apagado. El cofre queda sellado.')}<h2 id="stage-heading" tabindex="-1">Tiempo agotado</h2><p class="prompt">Habéis superado ${team.step} de ${room.titles.length} sellos.</p>`) + renderJournal();
    return;
  }
  if (team.chestOrder) {
    stage.innerHTML = `${progress}${wizard('Habéis superado el último sello y llegado al cofre.')}
      <div class="chest-illustration">${chestArt()}</div><p class="eyebrow">COFRE DESBLOQUEADO · ÚLTIMA SALA</p><h2 id="stage-heading" tabindex="-1">La cerradura del cofre</h2>
      <p class="prompt">Buscad la cifra de cada runa y escribidlas en el orden de la cerradura, de izquierda a derecha.</p>
      <section class="chest-runes" aria-labelledby="runes-found-heading">
        <h3 id="runes-found-heading">Vuestras runas y cifras</h3>${recoveredRunesMarkup()}
      </section>
      <h3 id="lock-order-heading">Orden de la cerradura</h3>
      <ol class="rune-order" aria-labelledby="lock-order-heading">${team.chestOrder.map(rune => `<li>${runeMark(rune)}</li>`).join('')}</ol>
      <form id="chest-form">
        <label>Combinación del cofre<input name="code" required type="text" inputmode="numeric" pattern="[0-9]{${team.chestOrder.length}}" maxlength="${team.chestOrder.length}" autocomplete="off" aria-describedby="code-format"></label>
        <p id="code-format" class="muted">${team.chestOrder.length} cifras seguidas.</p>
        <div class="answer-actions"><button class="button primary">Abrir el cofre ${icon('key')}</button></div>
      </form><p class="notice game-feedback" id="game-feedback" role="status"></p>`;
    if (feedback) message($('game-feedback'), feedback, 'success');
    $('chest-form').addEventListener('submit', event => {
      event.preventDefault();
      const code = new FormData(event.currentTarget).get('code');
      run(event.submitter, () => play('unlock', code), gameError);
    });
    return;
  }
  if (!team.challenge) {
    const returning = team.step === room.titles.length;
    stage.innerHTML = `<h2 id="stage-heading" tabindex="-1">${returning ? 'Volved al Santuario' : 'Explorad la fortaleza'}</h2>
      <p>${returning ? 'Volved a entrar por la puerta del Santuario para probar otra combinación.' : 'El mapa indica cómo llegar al siguiente desafío.'}</p>
      <button type="button" class="button ghost" id="back-to-map">Volver al mapa</button>` +
      progress + '<p class="notice game-feedback" id="game-feedback" role="status"></p>';
    $('back-to-map').addEventListener('click', focusBoard);
    if (feedback) message($('game-feedback'), feedback, 'success');
    return;
  }
  const { title, prompt, options, kind, terms, meanings, reasoningRequired, illustration, bossPhase } = team.challenge;
  const encounter = (bossPhase ? `<div class="boss-banner"><p class="eyebrow">IGNAR · FASE ${bossPhase} DE 2</p>
    <h3>${bossPhase === 1 ? 'Romped la defensa' : 'Derrotad al guardián'}</h3>
    <p>${bossPhase === 1 ? 'Superad esta prueba para romper la protección de Ignar.' : 'Superad la última prueba para derrotar a Ignar y acceder a la cerradura del cofre.'}</p></div>` : '') +
    encounterArt(illustration || 'archivo', Boolean(bossPhase));
  const answerField = kind === 'matching'
    ? '<fieldset class="matching-fields"><legend>Relacionad cada término con su significado</legend>'+terms.map((term, index) =>
      '<label>'+escape(term)+'<select name="match-'+index+'" required><option value="">Elegid un significado</option>'+
      meanings.map((meaning, id) => '<option value="'+id+'">'+escape(meaning)+'</option>').join('')+'</select></label>').join('')+'</fieldset>'
    : options.length
    ? `<fieldset class="options"><legend class="sr-only">Elegid una respuesta</legend>${options.map((option, index) =>
      `<label class="option"><input type="radio" name="answer" value="${index}" required><span>${escape(option)}</span></label>`).join('')}</fieldset>`
    : '<label>Vuestra respuesta<input name="answer" maxlength="350" required autocomplete="off" spellcheck="false"></label>';
  stage.innerHTML = `<div class="challenge-top">
    <p class="challenge-mode-kicker">DESAFÍO ${team.step + 1} DE ${room.titles.length}</p>
    <button type="button" class="button ghost" id="back-to-map">Ver mapa</button>
    </div><h2 id="stage-heading" tabindex="-1">${escape(title)}</h2><p class="prompt">${escape(prompt)}</p>
    ${wizard(team.step === 0
    ? 'Este es el primer sello. Leed el caso y elegid vuestra respuesta con cuidado. Cada fallo en este desafío tiene consecuencias.'
    : 'Cambiad de papel con vuestra pareja. Quien buscaba ahora propone la respuesta.', true)}
    <form id="answer-form">${answerField}
      ${reasoningRequired ? '<label>Vuestro razonamiento<textarea name="reasoning" rows="4" minlength="60" maxlength="1500" required placeholder="Explicad una contradicción, corregidla y añadid un ejemplo o una consecuencia."></textarea><small>La cerradura comprueba el dictamen. El docente podrá revisar vuestra explicación; el juego no la califica automáticamente.</small></label>' : ''}
      <div class="answer-actions"><button class="button primary">Probar el sello ${icon('key')}</button>
      <button type="button" class="button ghost" id="hint-button" aria-controls="hint">Pedir una pista al Mago</button></div>
    </form><p class="notice game-feedback" id="game-feedback" role="status"></p>
    ${encounter}${progress}`;
  $('back-to-map').addEventListener('click', focusBoard);
  if (feedback) message($('game-feedback'), feedback, 'success');
  $('answer-form').addEventListener('submit', event => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const value = data.get('answer');
    const answer = kind === 'matching' ? terms.map((_, index) => meanings[Number(data.get('match-'+index))]) :
      options.length ? options[Number(value)] : value;
    if (kind === 'matching' && new Set(answer).size !== answer.length) {
      gameError('Usad cada significado una sola vez.');
      return;
    }
    run(event.submitter, () => play('answer', answer, data.get('reasoning')), gameError);
  });
  if (team.revealedHint) showHint(team.revealedHint.level, team.revealedHint.text);
  $('hint-button').addEventListener('click', event => run(event.currentTarget, () => play('hint'), gameError));
}

function gameError(text) {
  if ($('game-feedback')) message($('game-feedback'), text, 'error');
}

function focusStage() {
  $('stage-heading')?.focus({ preventScroll: true });
  $('game-stage')?.scrollIntoView({ block: 'start' });
}

function showSealVictory(fragment, defeatedBoss, atChest, brokeDefense) {
  const dialog = document.createElement('dialog');
  dialog.className = 'seal-victory';
  dialog.setAttribute('aria-labelledby', 'seal-victory-title');
  const detail = defeatedBoss
    ? 'Habéis derrotado a Ignar y recuperado la última runa. Descifrad la combinación del cofre.'
    : brokeDefense
    ? 'Habéis roto la defensa de Ignar y recuperado una runa.'
    : atChest
    ? 'Habéis recuperado la última runa. Ya podéis descifrar la combinación.'
    : 'Habéis recuperado una runa para el cofre.';
  dialog.innerHTML = `<h2 id="seal-victory-title">Reto superado</h2>
    <p>${detail}</p>
    <p class="victory-rune" aria-label="Runa ${escape(fragment.rune)}, cifra ${escape(fragment.digit)}">
      ${runeMark(fragment.rune)} <strong>${escape(fragment.digit)}</strong>
    </p>
    <form method="dialog"><button class="button primary" autofocus>
      ${atChest ? 'Descifrar el cofre' : 'Continuar la expedición'}
    </button></form>`;
  dialog.addEventListener('close', () => {
    dialog.remove();
    if (view !== 'game') return;
    if (atChest) focusStage();
    else focusBoard();
  }, { once: true });
  game.append(dialog);
  dialog.showModal();
}

async function play(action, answer, reasoning, allowLifeCost) {
  const token = teamToken;
  const code = roomCode;
  const step = team.step;
  const result = await post('play', action, { code, token, step, answer, reasoning, allowLifeCost, revision: team.board.revision });
  if (view !== 'game' || teamToken !== token || step !== team.step) return;
  if (result.state.board.revision < team.board.revision) return;
  const changed = team.dead !== result.state.dead || team.board.revision !== result.state.board.revision || team.step !== result.state.step || team.expired !== result.state.expired || team.finished !== result.state.finished;
  const justDied = !team.dead && result.state.dead;
  const wonSeal = action === 'answer' && result.state.step > step;
  const brokeDefense = team.challenge?.bossPhase === 1;
  const openedDoor = result.openedDoor;
  const openedRoom = result.openedRoom;
  const defeatedBoss = !team.bossDefeated && result.state.bossDefeated;
  setTeam(result.state);
  if (changed && action === 'move' && result.path?.length) {
    await animateBoardMove(result);
    if (view !== 'game' || teamToken !== token || team.board.revision !== result.state.board.revision ||
        team.expired !== result.state.expired) return;
  }
  if (justDied) { diceAudio.stopMusic(); diceAudio.cue('death'); }
  else if (result.trapTriggered) diceAudio.cue('trap');
  if (changed && action === 'consume') {
    if (answer === 'pergamino') {
      renderStage(result.feedback);
    } else {
      renderAdventure({inventoryNotice:result.feedback});
      const meter = game.querySelector('.failure-meter');
      if (meter) meter.outerHTML = failureMeter();
      const lives = game.querySelector('.health-meter');
      if (lives) lives.outerHTML = healthMeter();
    }
    updateClock();
  } else if (room.training && changed && action === 'answer' && step === team.step && team.challenge && result.feedback) {
    gameError(result.feedback);
  } else if (changed) {
    const travelling = team.board.phase === 'travel' && !team.finished && !team.expired && !team.dead;
    if (team.finished || team.expired || team.dead) renderGame();
    else renderStage(travelling ? '' : result.feedback, { narration: travelling ? result.feedback : '' });
    if (result.trapTriggered) {
      await showDiscovery({
        name: 'Mecanismo oculto', symbol: '⚠', label: 'TRAMPA CAMUFLADA EN LA PUERTA',
        description: team.dead ? 'La trampa se ha activado al intentar cruzar.'
          : result.damage ? 'El mecanismo ya se ha gastado. Podéis volver a entrar por la misma puerta.'
          : 'Habéis neutralizado el mecanismo. La puerta queda libre.',
        note: result.feedback,
      });
    } else if (result.item && !team.dead) {
      await showPickup(result.item);
    }
    if (view !== 'game' || teamToken !== token) return;
    const enteringBoss = action === 'move' && Boolean(team.challenge?.bossPhase);
    if ((openedDoor || result.enteredDoor || enteringBoss) && !team.expired && !team.dead && !result.damage) {
      await showRoomDiscovery(openedRoom || team.board.activeRoom, openedDoor, team.challenge);
    }
    if (view !== 'game' || teamToken !== token) return;
    if (wonSeal) {
      showSealVictory(team.fragments.at(-1), defeatedBoss, Boolean(team.chestOrder), brokeDefense);
    } else if (team.board.phase === 'travel' && !team.finished && !team.expired && !team.dead) {
      focusBoard();
    } else focusStage();
  } else if (result.hint) {
    showHint(result.hintLevel, result.hint);
    $('hint').scrollIntoView({ block: 'nearest' });
  } else if (result.feedback) {
    message($('game-feedback'), result.feedback, 'error');
  }
}

let deadlineCheck = false;
let lastStatusCheck = 0;
function updateClock() {
  const clock = $('clock-value');
  if (!clock || team.finished || team.dead) return;
  const seconds = team.expired ? 0 : Math.max(0, Math.ceil((team.deadline - team.now - (performance.now() - syncedAt)) / 1000));
  clock.textContent = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
  $('clock').classList.toggle('urgent', seconds <= 300);
  if ((!seconds || performance.now() - lastStatusCheck >= 3000) && !team.expired && !team.dead && !deadlineCheck && !rolling) {
    lastStatusCheck = performance.now();
    deadlineCheck = true;
    play('status').catch(gameError).finally(() => setTimeout(() => { deadlineCheck = false; }, 2000));
  }
}

async function enterTeacher(key) {
  teacherKey = key;
  const { rooms = [] } = await post('teacher', 'check');
  $('teacher-access').hidden = true;
  $('teacher-tools').hidden = false;
  showActiveRooms(rooms);
}

function teacherError(text) { message(teacherMessage, text, 'error'); }
function teacherNotice(text) { message(teacherMessage, text, 'success'); }

function updateSourceList() {
  $('source-list').textContent = fileSources.map(source => source.name).join(' · ');
  updateAiStatus();
}
function missingAiSources() {
  if (!pendingAi) return [];
  const names = unitData().sources.map(source => source.name);
  return pendingAi.sourceRefs.filter(name => !names.includes(name));
}
function updateAiStatus() {
  const box = $('ai-import-status');
  if (!pendingAi) { box.hidden = true; return; }
  const missing = missingAiSources();
  box.hidden = false;
  box.textContent = missing.length
    ? 'Faltan los originales: ' + missing.join(', ') + '. Adjunta esos archivos en Archivos de la unidad; si faltan Apuntes de la unidad, pégalos en el campo de apuntes.'
    : 'Materiales vinculados. Revisa los retos, sus soluciones y referencias. Confirma la revisión antes de abrir la sala.';
}
function assertAiReady(review = false) {
  if (!pendingAi) return;
  const missing = missingAiSources();
  if (missing.length) throw new Error('Adjunta los materiales originales que faltan: ' + missing.join(', '));
  const extra = unitData().sources.filter(source => !pendingAi.sourceRefs.includes(source.name));
  if (extra.length) throw new Error('Hay materiales ajenos a esta preparación. Revisa las fuentes o crea nuevas instrucciones.');
  if (review && !$('ai-reviewed').checked) throw new Error('Revisa los retos y marca la casilla de revisión docente antes de abrir la sala.');
}
async function preparationStore(mode, value) {
  const db = await new Promise((resolve, reject) => {
    const request = indexedDB.open('camara-preparacion-ia', 1);
    request.onupgradeneeded = () => request.result.createObjectStore('draft');
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
    request.onblocked = () => reject(new Error('No se pudo abrir el borrador local.'));
  });
  try {
    return await new Promise((resolve, reject) => {
      const transaction = db.transaction('draft', mode === 'save' ? 'readwrite' : 'readonly');
      const store = transaction.objectStore('draft');
      const request = mode === 'save' ? store.put(value, 'last') : store.get('last');
      transaction.oncomplete = () => resolve(request.result);
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error || new Error('Borrador local interrumpido.'));
    });
  } finally { db.close(); }
}
async function importAnyUnit(data) {
  if (data?.format !== 'camara-del-mago-ia-1') {
    importUnit(data); return;
  }
  const ai = validateAiUnit(data);
  let saved;
  try { saved = await preparationStore('load'); } catch {}
  const snapshot = saved?.requestId === ai.requestId ? saved : null;
  if (snapshot) {
    const original = snapshot.unit;
    if (['title', 'minutes', 'pairCount', 'reward'].some(key => ai[key] !== original[key]) ||
      ai.challenges.length !== snapshot.count ||
      JSON.stringify(ai.sourceRefs) !== JSON.stringify(original.sources.map(source => source.name))) {
      throw new Error('La IA ha cambiado la configuración o las fuentes. Pídele que conserve los datos de las instrucciones copiadas y el número exacto de retos.');
    }
  }
  const available = snapshot ? snapshot.unit.sources : unitData().sources;
  const sources = ai.sourceRefs.map(name => available.find(source => source.name === name)).filter(Boolean);
  importUnit({ ...ai, format: 'camara-del-mago-1', sources });
  pendingAi = ai;
  $('ai-review-confirmation').hidden = false;
  $('ai-reviewed').checked = false;
  materialsChanged = false;
  updateSourceList();
}


function readPdf(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve({ name: file.name, pdf: reader.result.split(',')[1] });
    reader.onerror = () => reject(new Error(`No se pudo abrir ${file.name}.`));
    reader.readAsDataURL(file);
  });
}

function unitData() {
  const text = $('unit-text').value.trim();
  const sources = [...fileSources];
  if (text) sources.push({ name: 'Apuntes de la unidad', text });
  return {
    title: $('unit-title').value.trim() || (sources[0]?.name || 'Expedición de aula').replace(/\.(pdf|txt|md)$/i, '').slice(0, 100),
    minutes: Number($('unit-minutes').value),
    mode: $('unit-mode').value,
    maxRolls: $('unit-max-rolls').valueAsNumber,
    pairCount: Number($('unit-pairs').value),
    reward: $('unit-reward').value.trim() || 'Habéis abierto la Cámara del Mago. Revisad vuestro cuaderno y compartid qué estrategia os ayudó más.',
    sources,
    challenges,
  };
}

function editor() {
  $('review').hidden = false;
  $('add-challenge').hidden = challenges.length >= 8;
  $('challenges').innerHTML = challenges.map((challenge, index) => `
    <details class="editor" ${index === 0 ? 'open' : ''}>
      <summary><span>${index + 1} · ${escape(challenge.title)}${challenge.kind ? " · "+CHALLENGE_TYPES[challenge.kind] : ""}</span></summary>
      <div class="editor-fields" data-index="${index}">
        <label class="wide">Nombre del reto<input data-field="title" maxlength="60" value="${escape(challenge.title)}"></label>
        <label class="wide">Enunciado<textarea data-field="prompt" rows="3" maxlength="4000">${escape(challenge.prompt)}</textarea></label>
        ${challenge.kind === 'matching' ? `<label class="wide">Parejas (término | significado, una por línea)<textarea data-field="pairs" rows="5">${escape((challenge.pairs || []).map(pair => pair.term+' | '+pair.meaning).join('\n'))}</textarea></label>` : `
        <label>Respuestas aceptadas, una por línea<textarea data-field="answers" rows="3">${escape(challenge.answers.join('\n'))}</textarea></label>
        <label>Opciones, una por línea<textarea data-field="options" rows="3" placeholder="Deja vacío para una respuesta abierta.">${escape(challenge.options.join('\n'))}</textarea></label>`}
        <label class="wide">Primera pista opcional (orienta el razonamiento)<textarea data-field="strategy" rows="2" maxlength="500">${escape(challenge.strategy || '')}</textarea></label>
        <label class="wide">Segunda pista (orientación concreta)<textarea data-field="hint" rows="2" maxlength="500">${escape(challenge.hint)}</textarea></label>
        <label class="wide">Ilustración del encuentro<select data-field="illustration"><option value="">Automática</option>${ART_THEMES.map(theme => `<option value="${theme}" ${challenge.illustration===theme?"selected":""}>${escape(ART_LABELS[theme])}</option>`).join("")}</select></label>
        <label class="wide">Solución razonada (se muestra en el cierre a quien supere el reto)<textarea data-field="explanation" rows="4" maxlength="2500">${escape(challenge.explanation || '')}</textarea></label>
        <label class="wide">Fuente y apartado para el cierre<textarea data-field="reference" rows="2" maxlength="500">${escape(challenge.reference || '')}</textarea></label>
        <label class="wide"><span><input type="checkbox" data-field="reasoningRequired" ${challenge.reasoningRequired ? "checked" : ""}> Pedir justificación escrita (revisión docente)</span></label>
        <button type="button" class="button ghost" data-remove="${index}">Quitar reto</button>
      </div>
    </details>`).join('');
}

function importUnit(data) {
  if (data?.format !== 'camara-del-mago-1' || typeof data.title !== 'string' || typeof data.reward !== 'string' ||
    !Number.isInteger(data.minutes) || !Array.isArray(data.sources) || !Array.isArray(data.challenges) ||
    !data.sources.every(item => item && typeof item.name === 'string' && (typeof item.pdf === 'string' || typeof item.text === 'string')) ||
    !data.challenges.every(item => item && ['title', 'prompt', 'hint'].every(key => typeof item[key] === 'string') &&
      ['answers', 'options'].every(key => Array.isArray(item[key]) && item[key].every(value => typeof value === 'string')))) {
    throw new Error('Este archivo no es una unidad guardada por La Cámara del Mago.');
  }
  pendingAi = null;
  $('ai-review-confirmation').hidden = true;
  $('ai-import-status').hidden = true;
  $('published').hidden = true;
  $('unit-title').value = data.title;
  $('unit-minutes').value = data.minutes;
  $('unit-mode').value = data.mode === 'training' ? 'training' : 'classic';
  $('unit-max-rolls').value = data.maxRolls ?? 0;
  $('unit-count').value = Math.max(3, data.challenges.length);
  $('unit-pairs').value = Number.isInteger(data.pairCount) ? data.pairCount : 15;
  $('unit-reward').value = data.reward;
  const pasted = data.sources.find(source => !source.pdf && source.name === 'Apuntes de la unidad');
  $('unit-text').value = pasted?.text || '';
  $('unit-files').value = '';
  fileSources = data.sources.filter(source => source !== pasted);
  challenges = data.challenges;
  materialsChanged = false;
  updateSourceList();
  editor();
}

function showActiveRooms(rooms) {
  $('active-rooms').hidden = !rooms.length;
  $('active-room-buttons').replaceChildren(...rooms.map(({ code, title }) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'button ghost';
    button.textContent = `${title} · ${code}`;
    button.addEventListener('click', () => run(button, async () => {
      showPublished(await post('teacher', 'room', { code }));
      message(teacherMessage);
    }, teacherError));
    return button;
  }));
}

function showPublished(result) {
  const { code } = result;
  const path = `/?sala=${encodeURIComponent(code)}`;
  const published = $('published');
  published.hidden = false;
  published.innerHTML = `<p class="eyebrow">03 / SALA ABIERTA</p><h2>Código ${escape(code)}</h2>
    <p class="muted">Comparte el enlace de sala con la clase y entrega en privado un código distinto a cada pareja.</p>
    ${result.previewAvailable ? `<div class="answer-actions"><button class="button primary" id="preview-room" type="button">Probar como alumno</button></div>
    <p class="pass-help muted">La prueba abre una copia con los mismos retos, materiales y recompensa configurada.</p>`
    : '<p class="muted">Para probar sin código, guarda la unidad y vuelve a arrancar el juego con la versión actualizada.</p>'}
    <div class="links">
    ${result.addresses.length ? '' : `<a href="${path}" target="_blank" rel="noopener">Enlace local de la sala para las parejas</a>`}
    ${result.addresses.map(address => `<a href="${escape(address + path)}" target="_blank" rel="noopener">${escape(address + path)}</a>`).join('')}</div>
    <details class="editor"><summary>Códigos privados de pareja (${result.passes.length})</summary>
      <p class="pass-help muted">Cada pareja introduce su código después de abrir el enlace de la sala.</p>
      <ol class="pair-codes">${result.passes.map(pass => `<li><code>${escape(pass.slice(0, 5))}-${escape(pass.slice(5))}</code></li>`).join('')}</ol>
    </details>
    <div class="answer-actions"><button class="button ghost" type="button" id="refresh-teams">Ver progreso de las parejas</button></div>
    <div class="teams" id="teams" role="status"></div>`;
  const teamList = $('teams');
  $('preview-room')?.addEventListener('click', event => run(event.currentTarget, async () => {
    const preview = await post('teacher', 'preview', { code });
    await openRoom(preview.code);
  }, teacherError));
  $('refresh-teams').addEventListener('click', event => run(event.currentTarget, async () => {
    const result = await post('teacher', 'teams', { code });
    teamList.innerHTML = result.teams.length ? result.teams.map(team =>
      `<div class="team-row"><strong>${escape(team.name)} · ${escape(team.role || '')}</strong><span>${escape(team.progress)} · ${escape(team.state)} · Vida: ${team.health}/3 · Movimientos: ${team.moves} · Fallos totales: ${team.incorrect} · Fallos por reto: ${team.misses.join("/")} · Pistas por reto: ${team.hints.join("/")}</span>${team.reasoning?.length ? `<details><summary>Ver justificaciones</summary>${team.reasoning.map(item => `<h4>${escape(item.title)}</h4><p class="prompt">${escape(item.text)}</p>`).join('')}</details>` : ''}</div>`).join('')
      : '<p class="muted">Aún no ha empezado ninguna pareja.</p>';
  }, teacherError));
  published.scrollIntoView({ block: 'start' });
}

window.addEventListener('pagehide', () => diceAudio.stopMusic());
document.addEventListener('pointerdown', () => {
  if (view === 'game' && team && !team.dead && !team.finished && !team.expired && !diceAudio.music && !diceAudio.muted) {
    void diceAudio.unlock().then(() => { if (view === 'game' && team && !team.dead && !team.finished && !team.expired) void diceAudio.startMusic(); });
  }
});

$('student-tab').addEventListener('click', exitRoom);
$('go-room').addEventListener('click', () => $('room-code').focus());
$('demo').addEventListener('click', event => run(event.currentTarget, () => openRoom('DEMO'),
  text => message($('entry-message'), text, 'error')));
$('room-form').addEventListener('submit', event => {
  event.preventDefault();
  run(event.submitter, () => openRoom($('room-code').value),
    text => message($('entry-message'), text, 'error'));
});
$('teacher-tab').addEventListener('click', () => {
  if ($('teacher-tools').hidden && ['localhost', '127.0.0.1'].includes(location.hostname)) {
    location.assign('/docente');
    return;
  }
  show('teacher');
});
$('unit-text').addEventListener('input', () => { materialsChanged = true; if (pendingAi) $('ai-reviewed').checked = false; updateAiStatus(); });
$('unit-files').addEventListener('change', async event => {
  const input = event.currentTarget;
  const files = [...event.currentTarget.files];
  if (files.length > 8 || files.reduce((total, file) => total + file.size, 0) > 24 * 1024 * 1024 ||
    files.some(file => file.size > 10 * 1024 * 1024)) {
    input.value = '';
    teacherError('Puedes añadir hasta 8 archivos, con un máximo de 10 MB por archivo y 24 MB en total.');
    return;
  }
  await run(input, async () => {
    const uploaded = await Promise.all(files.map(async file => {
      if (/\.pdf$/i.test(file.name)) return readPdf(file);
      if (!/\.(txt|md)$/i.test(file.name)) throw new Error(`El formato de ${file.name} debe ser PDF, TXT o Markdown.`);
      const text = (await file.text()).trim();
      if (!text || text.length > 120000) throw new Error(`${file.name} debe contener entre 1 y 120 000 caracteres de texto.`);
      return { name: file.name, text };
    }));
    if (pendingAi) {
      if (uploaded.some(source => !pendingAi.sourceRefs.includes(source.name))) throw new Error('Los nombres de los archivos deben coincidir con sourceRefs del JSON de IA.');
      const merged = new Map(fileSources.map(source => [source.name, source]));
      for (const source of uploaded) merged.set(source.name, source);
      if (merged.size > 8 || [...merged.values()].reduce((size, source) => size + (source.pdf ? source.pdf.length * 0.75 : source.text.length * 3), 0) > 24 * 1024 * 1024)
        throw new Error('Los materiales vinculados superan el máximo de 8 archivos o 24 MB.');
      fileSources = [...merged.values()];
      $('ai-reviewed').checked = false;
    } else fileSources = uploaded;
    materialsChanged = true;
    updateSourceList();
    message(teacherMessage);
  }, teacherError);
});
$('unit-form').addEventListener('submit', event => {
  event.preventDefault();
  run(event.submitter, async () => {
    if ($('unit-files').disabled) throw new Error('Espera a que se terminen de cargar los archivos.');
    message(teacherMessage, 'El Mago está leyendo los materiales…');
    const { sources } = unitData();
    const textAtStart = $('unit-text').value;
    const filesAtStart = fileSources;
    const count = Number($('unit-count').value);
    const result = await post('teacher', 'generate', { sources, count });
    pendingAi = null;
    $('ai-review-confirmation').hidden = true;
    updateAiStatus();
    challenges = result.challenges;
    materialsChanged = textAtStart !== $('unit-text').value || filesAtStart !== fileSources;
    editor();
    const unreadable = result.unreadable.length ? ` Sin texto extraíble en ${result.unreadable.join(', ')}.` : '';
    const missing = challenges.length < count ? ' Añade apuntes, regenera el borrador o completa los retos a mano.' : '';
    message(teacherMessage, `${challenges.length} de ${count} retos generados.${unreadable}${missing}`, missing || unreadable ? '' : 'success');
    $('review').scrollIntoView({ block: 'start' });
  }, teacherError);
});
$('challenges').addEventListener('input', event => {
  const field = event.target.dataset.field;
  if (!field) return;
  const index = Number(event.target.closest('[data-index]').dataset.index);
  if (pendingAi) $('ai-reviewed').checked = false;
  challenges[index][field] = field === 'pairs' ? event.target.value.split('\n').filter(line => line.trim()).map(line => {
    const separator = line.indexOf('|');
    return separator < 0 ? {term:line.trim(), meaning:''} :
      {term:line.slice(0,separator).trim(), meaning:line.slice(separator+1).trim()};
  }) : field === 'illustration' ? (event.target.value || undefined) : field === 'reasoningRequired' ? event.target.checked : ['answers', 'options'].includes(field)
    ? event.target.value.split('\n').map(value => value.trim()).filter(Boolean)
    : event.target.value;
  if (field === 'title') event.target.closest('details').querySelector('summary span').textContent =
    `${index + 1} · ${event.target.value}`;
});
$('challenges').addEventListener('click', event => {
  if (!Object.hasOwn(event.target.dataset, 'remove')) return;
  challenges.splice(Number(event.target.dataset.remove), 1);
  editor();
});
$('add-challenge').addEventListener('click', () => {
  if (challenges.length >= 8) return;
  challenges.push({ title: `Sello ${challenges.length + 1}`, prompt: '', answers: [], options: [], hint: '' });
  editor();
  const last = $('challenges').lastElementChild;
  last.open = true;
  last.querySelector('input').focus();
});
$('import-unit').addEventListener('click', () => $('unit-file').click());
$('unit-file').addEventListener('change', async event => {
  const file = event.currentTarget.files[0];
  if (!file) return;
  try {
    if (file.size > 36 * 1024 * 1024) throw new Error('La unidad guardada supera el tamaño admitido.');
    await importAnyUnit(parseJsonFile(await file.text()));
    teacherNotice(pendingAi ? (missingAiSources().length ? 'JSON de IA cargado. Adjunta los originales indicados y revisa los retos.' : 'JSON de IA cargado y materiales recuperados. Revisa las soluciones y abre la sala.') : 'Unidad cargada. Ya puedes revisar los retos o abrir una nueva sala.');
  } catch (error) {
    teacherError(error instanceof SyntaxError ? 'El archivo no contiene una unidad válida.' : error.message);
  } finally {
    $('unit-file').value = '';
  }
});
$('save-unit').addEventListener('click', () => {
  if (!$('unit-form').reportValidity()) return;
  try { assertAiReady(); } catch (error) { teacherError(error.message); return; }
  const data = { format: 'camara-del-mago-1', ...unitData() };
  const link = document.createElement('a');
  link.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
  link.download = 'unidad-camara-del-mago.json';
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  teacherNotice('Unidad guardada. El archivo incluye materiales, soluciones y recompensa.');
});
$('publish').addEventListener('click', event => run(event.currentTarget, async () => {
  if (!$('unit-form').reportValidity()) return;
  if ($('unit-files').disabled) throw new Error('Espera a que se terminen de cargar los archivos.');
  assertAiReady(true);
  if (materialsChanged && !pendingAi) throw new Error('Los materiales han cambiado. Genera y revisa un nuevo borrador antes de abrir la sala.');
  showPublished(await post('teacher', 'publish', unitData()));
  teacherNotice('Sala abierta.');
  const { rooms = [] } = await post('teacher', 'check');
  showActiveRooms(rooms);
}, teacherError));


$('export-ai').addEventListener('click', event => run(event.currentTarget, async () => {
  if (!$('unit-form').reportValidity()) return;
  if ($('unit-files').disabled) throw new Error('Espera a que terminen de cargarse los archivos.');
  const unit = unitData();
  if (!unit.sources.length) throw new Error('Adjunta tus fuentes o pega los apuntes antes de preparar las instrucciones.');
  const requestId = crypto.randomUUID();
  const settings = {requestId, count: Number($('unit-count').value), level: $('ai-level').value.trim(), difficulty: $('ai-difficulty').value};
  if (!settings.level) throw new Error('Indica el nivel del alumnado.');
  const instructions = buildAiInstructions(unit, settings);
  $('chatgpt-step').hidden = false;
  const field = $('chatgpt-instructions');
  field.value = instructions;
  const copying = navigator.clipboard?.writeText(instructions);
  window.open('https://chatgpt.com/', '_blank', 'noopener,noreferrer');
  let copied = false;
  try {
    if (!copying) throw new Error('Portapapeles no disponible.');
    await copying;
    copied = true;
  }
  catch { field.focus(); field.select(); }
  try { await preparationStore('save', {requestId, unit, count: settings.count}); } catch {}
  teacherNotice(copied ? 'Instrucciones copiadas. Pégalas en ChatGPT y adjunta los PDF si los hay.' :
    'Copia el texto seleccionado con Ctrl+C, pégalo en ChatGPT y adjunta los PDF si los hay.');
}, teacherError));
$('paste-ai-load').addEventListener('click', event => run(event.currentTarget, async () => {
  await importAnyUnit(parseJsonFile($('paste-ai-json').value));
  $('paste-ai-json').value = '';
  teacherNotice(pendingAi && missingAiSources().length ? 'JSON cargado; adjunta los originales que faltan.' : 'JSON cargado. Revisa los retos y las soluciones antes de abrir la sala.');
  $('review').scrollIntoView({block:'start'});
}, teacherError));
const fromHash = new URLSearchParams(location.hash.slice(1)).get('docente');
const fromQuery = new URLSearchParams(location.search).get('sala');
if (fromHash) {
  history.replaceState(null, '', location.pathname);
  show('teacher');
  enterTeacher(fromHash).catch(teacherError);
} else if (fromQuery) {
  $('room-code').value = fromQuery;
  openRoom(fromQuery).catch(text => message($('entry-message'), text.message, 'error'));
}
