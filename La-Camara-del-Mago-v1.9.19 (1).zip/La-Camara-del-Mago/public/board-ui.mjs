import { ART_THEMES, ART_LABELS } from '/encounters.mjs';
import { ROLES } from '/roles.mjs';

export const ITEMS = {
  amuleto: { symbol: '🔮', name: 'Amuleto protector', description: 'Bloquea el efecto de la próxima trampa.' },
  reloj: { symbol: '⏳', name: 'Reloj de arena', description: 'Añade 45 segundos al tiempo de la pareja.' },
  pocion: { symbol: '❤️', name: 'Poción de vida', description: 'Recupera 1 punto de vida o, si ya tenéis 3, borra un fallo del desafío actual.' },
  brujula: { symbol: '🧭', name: 'Brújula arcana', description: 'Añade 3 pasos a un movimiento. Solo se puede usar una por movimiento.' },
  pergamino: { symbol: '📜', name: 'Pergamino de estudio', description: 'Revela la siguiente pista del sello actual. Usadlo dentro de un reto.' },
};

const esc = value => String(value ?? '').replace(/[&<>"']/g, character => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[character]));

const ROOM_MARKS = new Map([
  ['umbral', '⌑'], ['espejos', '◈'], ['biblioteca', '▤'], ['runas', '✣'],
  ['armeria', '⚔︎'], ['sombras', '☾'], ['ignar', '♨'], ['santuario', '✺'],
]);
const ROOM_ART = new Map([
  ['umbral', 'portales'], ['espejos', 'canales'], ['biblioteca', 'archivo'], ['runas', 'alianza'],
  ['armeria', 'taller'], ['sombras', 'sendas'], ['ignar', 'dragon'], ['santuario', 'tesoro'],
]);

function roomMark(theme) {
  return ROOM_MARKS.has(theme) ? `<span class="room-mark theme-${theme}" aria-hidden="true">${ROOM_MARKS.get(theme)}</span>` : '';
}

function columnLabel(number) {
  let label = '';
  for (let value = number; value > 0; value = Math.floor((value - 1) / 26)) {
    label = String.fromCharCode(65 + (value - 1) % 26) + label;
  }
  return label;
}

function squareLabel(index, width) {
  return `${columnLabel(index % width + 1)}${Math.floor(index / width) + 1}`;
}

function wallMarkup(index, columns, rows) {
  const column = index % columns;
  const row = Math.floor(index / columns);
  const north = row === 0;
  const south = row === rows - 1;
  const west = column === 0;
  const east = column === columns - 1;
  if ((north || south) && (west || east)) {
    const corner = (north ? 'n' : 's') + (west ? 'w' : 'e');
    return `<span class="dungeon-wall dungeon-bastion bastion-${corner}" aria-hidden="true">
      <img class="dungeon-gargoyle" src="/gargola.webp" alt="" draggable="false">
    </span>`;
  }
  if (north || south || west || east) {
    const axis = north || south ? 'horizontal' : 'vertical';
    return `<span class="dungeon-wall dungeon-rampart rampart-${axis}" aria-hidden="true"></span>`;
  }
  return '<span class="dungeon-wall" aria-hidden="true"></span>';
}

export function roomIllustrationMarkup(room, className = 'room-entry-art') {
  const theme = ROOM_ART.get(room?.theme) ?? ART_THEMES[room?.index] ?? ART_THEMES[0];
  const index = ART_THEMES.indexOf(theme);
  const description = ART_LABELS[theme] || 'Sala fantástica de la fortaleza';
  return `<div class="${className} room-art-${index}" role="img" aria-label="${esc(description)}"></div>`;
}

export function boardMarkup(config, team, {
  soundOn,
  bagOpen,
  rolling = false,
  narration = '',
  inventoryNotice = '',
} = {}) {
  const board = team.board;
  const playing = !team.finished && !team.dead && !team.expired;
  const active = board.phase === 'travel' && playing;
  const objective = active ? board.objective : null;
  const returning = active && board.returningToChest;
  const rolled = active && board.remainingSteps > 0;
  const lastRoll = rolled && !rolling && board.lastRoll;
  const lastRollWarning = active && !rolling && board.remainingRolls === 1;
  const directTarget = board.directTarget;
  const suggested = !rolling ? objective?.recommended : undefined;
  const objectiveCoordinate = objective ? squareLabel(objective.square, config.width) : '';
  const role = ROLES.find(race => race.id === team.role) ?? ROLES.at(-1);
  const position = squareLabel(board.position, config.width);
  const itemCount = Object.values(board.inventory).reduce((sum, count) => sum + count, 0);
  const inventory = `<details class="board-inventory" ${bagOpen ? 'open' : ''}>
    <summary><img src="/bolsa-cuero.png" alt=""><span>Bolsa</span><span class="bag-count">${itemCount}</span></summary>
    <div class="inventory-content"><p>Terminad el movimiento en una casilla ◆ para descubrir y recoger su objeto.</p>
      <div class="inventory-slots">${Object.entries(ITEMS).map(([id, item]) => {
        const count = board.inventory?.[id] ?? 0;
        const armed = (id === 'amuleto' && board.shieldArmed) || (id === 'brujula' && board.compassActive);
        const enabled = !rolling && count > 0 && !armed && (id !== 'pocion' || team.health < 3 || team.failures > 0) &&
          (id !== 'pergamino' || (Boolean(team.challenge) && (team.revealedHint?.level ?? 0) < 2)) &&
          !team.dead && !team.expired && !team.finished;
        return `<article class="inventory-slot${count ? ' stocked' : ''}">
          <span class="inventory-icon" aria-hidden="true">${item.symbol}</span>
          <div class="inventory-details"><strong>${item.name}</strong><p>${item.description}</p></div>
          <span class="inventory-count" aria-label="${count} en la mochila">×${count}</span>
          <button type="button" class="button ghost" data-consume="${id}" aria-label="Usar ${item.name.toLowerCase()}" ${enabled ? '' : 'disabled'}>${armed ? 'Activo' : 'Usar'}</button>
        </article>`;
      }).join('')}</div>
      <p class="inventory-feedback" role="status">${esc(inventoryNotice)}</p>
    </div>
  </details>`;

  const labels = {
    entrance: 'Entrada de la mazmorra', door: 'Puerta cerrada', archive: 'Archivo, contiene una pista',
    trap: 'Trampa del pasadizo', floor: 'Pasillo', room: 'Sala oculta', item: 'Objeto sin identificar', seal: 'Sello de desafío',
    'chest-sealed': 'Cofre cerrado en el Santuario', chest: 'Cofre de las runas, junto al sello final', 'chest-open': 'Cofre de las runas abierto',
  };
  const symbols = { entrance: '⌂', archive: '✎', trap: '⚠', item: '◆', seal: '✦', 'chest-sealed': '▣', chest: '▣', 'chest-open': '▣' };
  const rowCount = Math.ceil(board.tiles.length / config.width);
  const tileMarkup = board.tiles.map((tile, index) => {
    const theme = ROOM_MARKS.has(tile?.theme) ? ` theme-${tile.theme}` : '';
    if (tile?.kind === 'hidden' && theme) return `<span class="dungeon-wall undiscovered-room${theme}" aria-hidden="true"></span>`;
    if (!tile || tile.kind === 'hidden') return wallMarkup(index, config.width, rowCount);
    const coordinate = squareLabel(index, config.width);
    const reachable = active && !rolling && Object.hasOwn(board.paths, index);
    const costsLife = reachable && board.lifeCostSquares.includes(index);
    const isDoor = tile.kind === 'door';
    const locked = isDoor && tile.room > team.step;
    const isObjective = index === objective?.square;
    const chestAvailable = tile.kind === 'chest' && Boolean(team.chestOrder) && !team.expired;
    const current = index === board.position;
    const opened = tile.room !== undefined && board.openedRooms.includes(tile.room);
    const checkpoint = index === board.checkpoint && !current;
    const cleared = tile.kind === 'seal' && tile.room < team.step;
    const spent = board.visitedSpecial.includes(index);
    const symbol = tile.kind === 'chest-sealed' || tile.kind === 'chest' || tile.kind === 'chest-open' ? symbols[tile.kind] : current ? '●' : checkpoint ? '⚑' : cleared ? '✓'
      : spent ? '' : symbols[tile.kind] || '';
    const tileName = isDoor ? `Puerta del reto ${tile.room + 1}, ${tile.name}` : tile.kind === 'seal' ? `Sello de ${tile.name}` : tile.name || labels[tile.kind] || 'Casilla';
    const label = `${coordinate} · ${tileName}`;
    const doorNote = locked ? `Puerta ${coordinate} bloqueada. Superad primero el desafío ${tile.room}.`
      : !active ? 'Terminad el desafío actual para volver a moveros.'
      : rolling ? 'Esperad a que termine la tirada.'
      : board.reentry ? 'Volved por la puerta señalada en el mapa.'
      : rolled ? `La puerta ${coordinate} queda fuera de alcance. Elegid una casilla iluminada para acercaros.`
      : `Tirad el dado para acercaros a la puerta ${coordinate}.`;
    const inspectDoor = playing && isDoor && !reachable && !current;
    const distance = reachable ? board.paths[index].length : 0;
    const hint = inspectDoor ? `${label}. ${doorNote}`
      : `${label}${isObjective ? ' · Objetivo actual' : ''}${reachable ? ` · Al alcance en ${distance} ${distance === 1 ? 'paso' : 'pasos'}` : ''}${costsLife ? ' · Cuesta 1 vida' : ''}`;
    const emblem = tile.kind === 'seal' && !cleared && !checkpoint ? roomMark(tile.theme) : '';
    const tileSymbol = isDoor
      ? `<span class="door-number" aria-hidden="true">${tile.room + 1}</span>${locked ? '<span class="tile-lock" aria-hidden="true"></span>' : ''}`
      : emblem || symbol;
    const token = current ? `<span class="dungeon-token" aria-hidden="true">
      <img src="/miniatura-${role.id}.webp" alt="" draggable="false">
    </span>` : '';
    return `<button type="button" class="dungeon-tile ${tile.kind}${theme}${current ? ' current' : ''}${reachable ? ' reachable' : ''}${chestAvailable ? ' chest-available' : ''}${opened ? ' opened' : ''}${cleared ? ' cleared' : ''}${spent ? ' spent' : ''}${locked ? ' door-locked' : ''}${isObjective ? ' objective-tile' : ''}${index === suggested && !isObjective ? ' suggested-tile' : ''}"
      data-square="${index}" ${costsLife ? 'data-life-cost' : ''} ${inspectDoor ? `data-door-note="${esc(doorNote)}"` : ''}
      ${reachable || chestAvailable || inspectDoor ? '' : 'disabled'} title="${esc(hint)}"
      aria-label="${esc(current ? 'Vuestra posición: ' + label : hint)}">${isDoor ? token + tileSymbol : token || tileSymbol}</button>`;
  });
  const columnHeadings = Array.from({ length: config.width }, (_, index) =>
    `<span class="dungeon-axis dungeon-axis-x" aria-hidden="true">${columnLabel(index + 1)}</span>`).join('');
  const mapRows = Array.from({ length: rowCount }, (_, row) => {
    const start = row * config.width;
    const cells = tileMarkup.slice(start, start + config.width).join('');
    return `<span class="dungeon-axis dungeon-axis-y" aria-hidden="true">${row + 1}</span>${cells}`;
  }).join('');
  const squares = `<span aria-hidden="true"></span>${columnHeadings}${mapRows}`;
  const coordinateHelp = `Coordenadas: eje X, ${columnLabel(1)}–${columnLabel(config.width)}; eje Y, 1–${rowCount}.`;

  const canRoll = active && !rolled && board.remainingRolls !== 0;
  const bonus = rolled ? Math.max(0, board.remainingSteps - board.rollValue) : 0;
  const stepUnit = board.remainingSteps === 1 ? 'paso' : 'pasos';
  const movementText = team.dead
    ? 'La expedición ha terminado.'
    : team.expired
    ? 'Se ha agotado el tiempo; el cofre permanece cerrado.'
    : board.phase === 'chest'
    ? 'Habéis llegado al cofre. Introducid su combinación en el panel de la aventura.'
    : rolling ? 'Lanzando el dado…'
    : rolled ? `Dado ${board.rollValue}${bonus ? ` + ${bonus} de bonificación` : ''} · Alcance: ${board.remainingSteps} ${stepUnit}.`
    : '';
  const suggestedTile = board.tiles[suggested];
  const directAction = returning ? 'Volver al cofre' : board.reentry ? 'Volver al sello' : 'Ir al sello';
  const destinationAction = directTarget !== undefined ? directAction
    : suggested === objective?.square && returning ? 'Regresar por'
    : suggestedTile?.kind === 'door' && suggestedTile.room === team.step ? 'Entrar por'
    : suggestedTile?.kind === 'seal' && suggestedTile.room === team.step ? 'Ir al sello'
    : 'Avanzar a';
  const suggestedCost = lastRoll && board.lifeCostSquares.includes(suggested);
  const objectiveGuide = objective && (rolling ? ''
    : lastRoll && directTarget === undefined ? 'El objetivo queda fuera de alcance. Moveros con esta tirada cuesta 1 vida.'
    : lastRoll ? 'Podéis entrar con esta tirada. Explorar fuera del objetivo cuesta 1 vida.'
    : board.reentry && directTarget !== undefined ? 'Volved a entrar para reintentar.'
    : board.refillRequired ? 'Tiradas agotadas. Gastad una vida para recuperar las tiradas del sello.'
    : !rolled ? `Tirad el dado para llegar ${objective.kind === 'door' ? 'a la puerta' : 'al sello'} <strong>${objectiveCoordinate}</strong>.`
    : suggested === objective.square ? `El objetivo <strong>${objectiveCoordinate}</strong> está al alcance.`
    : `Seguid hacia <strong>${objectiveCoordinate}</strong> o elegid otra casilla iluminada.`);
  const openedCount = board.openedRooms.length;
  const health = Math.max(0, Math.min(3, team.health ?? 3));
  const healthText = `${'♥'.repeat(health)}${'♡'.repeat(3 - health)}`;
  const chestVisible = board.tiles.some(tile => tile?.kind === 'chest-sealed');
  const chestStatus = team.finished
    ? '<p class="chest-map-status" role="status">Cofre abierto. La recompensa está en el panel de la aventura.</p>'
    : team.expired
    ? '<p class="chest-map-status" role="status">Se agotó el tiempo antes de abrir el cofre.</p>'
    : team.dead
    ? '<p class="chest-map-status" role="status">La expedición terminó antes de abrir el cofre.</p>'
    : board.phase === 'chest'
    ? '<p class="chest-map-status" role="status">Cofre desbloqueado en la última sala. Seleccionad la casilla ▣ para ir a la combinación.</p>'
    : returning
    ? '<p class="chest-map-status">Las runas se conservan. Volved al Santuario para probar otra combinación.</p>'
    : chestVisible
    ? '<p class="chest-map-status">Cofre sellado en el Santuario. Al superar el último reto, seleccionad ▣ para ir a la combinación.</p>'
    : '<p class="chest-map-status">El cofre aparecerá en el santuario al superar el último sello.</p>';
  const activeRoom = board.activeRoom;
  const roomScene = activeRoom ? `<section class="room-entry-scene" aria-label="Sala descubierta">
    ${roomIllustrationMarkup(activeRoom)}
    <div class="room-entry-shade"></div>
    <div class="room-entry-caption"><p class="eyebrow">PLANO INTERIOR · SALA ABIERTA</p>
      <h3>${esc(activeRoom.name || 'Sala oculta')}</h3></div>
    <span class="room-entry-sigil" aria-hidden="true">${roomMark(activeRoom.theme)}</span>
  </section>` : '';
  const movementConsole = `<section class="movement-console" aria-label="Dado y movimiento">
    <div class="die-holder">
      <span class="die-shadow" aria-hidden="true"></span>
      <canvas class="movement-die" width="440" height="400" role="img"
        aria-label="${board.rollValue == null ? 'Dado de doce caras' : `Dado de doce caras, resultado ${board.rollValue}`}"></canvas>
    </div>
    <div class="movement-instructions">
      <p class="eyebrow">${returning ? 'REGRESO AL COFRE' : objective ? `DESAFÍO ${team.step + 1}` : team.challenge ? `DESAFÍO ${team.step + 1} · SALA ABIERTA` : 'MOVIMIENTO · DADO DE 12 CARAS'}</p>
      ${objective ? `<h3 class="movement-objective">${roomMark(objective.theme)} ${esc(objective.name)}</h3>` : ''}
      <p class="movement-status" role="status">${esc(movementText)}</p>
      ${objectiveGuide ? `<p class="objective-instruction">${objectiveGuide}</p>` : ''}
      ${lastRoll ? '<p class="roll-budget"><strong>Última tirada en juego</strong></p>'
        : active && board.maxRolls ? `<p class="roll-budget">Tiradas disponibles: <strong>${board.remainingRolls} de ${board.maxRolls}</strong></p>` : ''}
      ${lastRollWarning ? `<p class="last-roll-warning" role="status">Os queda 1 tirada para ir ${returning ? 'al cofre' : 'al sello'}.</p>` : ''}
      ${canRoll ? `<button type="button" class="button primary" id="roll-dice" ${rolling ? 'disabled' : ''}>${lastRollWarning ? 'Usar última tirada' : 'Tirar'}</button>` : ''}
      ${suggested !== undefined ? `<button type="button" class="button primary" data-move-to="${suggested}">${destinationAction} ${squareLabel(suggested, config.width)}${suggestedCost ? ' (−1 vida)' : ''}</button>` : ''}
      ${lastRoll && board.lifeCostSquares.length ? '<button type="button" class="button ghost" id="choose-exploration">Explorar (−1 vida)</button>' : ''}
      ${active && board.refillRequired ? '<button type="button" class="button ghost" id="refill-rolls">Recuperar tiradas (−1 vida)</button>' : ''}
      ${playing && team.challenge ? '<button type="button" class="button primary" data-stage-link>Ir al desafío</button>' : ''}
      ${playing && team.chestOrder ? '<button type="button" class="button primary" data-stage-link>Ir al cofre</button>' : ''}
      <p class="move-feedback" id="move-feedback" role="status">${esc(narration)}</p>
    </div>
    <dl class="movement-stats"><div><dt>Movimientos</dt><dd>${board.moves}</dd></div><div><dt>Salas abiertas</dt><dd>${openedCount}</dd></div><div class="health-stat"><dt>Vida</dt><dd class="health-hearts" aria-label="${health} de 3 puntos de vida">${healthText} <span>${health}/3</span></dd></div></dl>
  </section>`;

  return `<div class="dungeon-frame${activeRoom ? ' in-room' : ''}">
    <span class="frame-corner corner-nw" aria-hidden="true">✥</span><span class="frame-corner corner-ne" aria-hidden="true">✥</span>
    <span class="frame-corner corner-sw" aria-hidden="true">✥</span><span class="frame-corner corner-se" aria-hidden="true">✥</span>
    <header class="frame-heading"><span class="frame-sigil" aria-hidden="true">ᛟ</span><div><p class="eyebrow">${activeRoom ? 'SALA EXPLORABLE' : 'PLANO DEL BASTIÓN'}</p><h2>${esc(activeRoom?.name || 'La fortaleza del Mago')}</h2></div>
      <button type="button" class="button ghost" id="toggle-dice-sound" aria-pressed="${!soundOn}">Audio: ${soundOn ? 'activado' : 'silenciado'}</button>
    </header>
    ${movementConsole}
    ${roomScene}
    <div class="dungeon-grid-wrap"><div class="dungeon-grid" role="group" aria-label="Mapa de la fortaleza con coordenadas alfanuméricas">${squares}</div></div>
    <p class="door-feedback" id="door-feedback" role="status"></p>
    <p class="coordinate-help">${coordinateHelp} Cada casilla lleva una coordenada, por ejemplo H8.</p>
    <p class="dungeon-legend"><strong>${esc(role.name)} · ${position}</strong> <span>⌂</span> Entrada <span>N.º</span> Puerta <span class="tile-lock" aria-hidden="true"></span> Bloqueada <span>✦</span> Sello <span>✎</span> Archivo <span>◆</span> Objeto <span>⚑</span> Retorno <span>▣</span> Cofre</p>
    ${chestStatus}
    ${inventory}
  </div>`;
}
