// Sonido local de dado contra piedra: no requiere archivos ni servicios externos.
export class DiceAudio {
 constructor(muted=false){this.muted=muted;this.context=null;this.master=null;}
 async unlock(){
  try{
   if(!this.context){
    const Engine=globalThis.AudioContext||globalThis.webkitAudioContext;if(!Engine)return;
    this.context=new Engine();this.master=this.context.createGain();
    this.master.gain.value=this.muted?0:.23;this.master.connect(this.context.destination);
   }
   if(this.context.state==='suspended')await this.context.resume();
  }catch{}
 }
 setMuted(muted){this.muted=muted;if(this.master)this.master.gain.setValueAtTime(muted?0:.23,this.context.currentTime);}
 play(){
  if(this.muted||!this.context||this.context.state!=='running')return;
  const ctx=this.context,now=ctx.currentTime;
  for(const [i,t] of [0,.075,.16,.28,.41].entries()){
   const duration=.06+i*.007,buffer=ctx.createBuffer(1,Math.ceil(ctx.sampleRate*duration),ctx.sampleRate),data=buffer.getChannelData(0);
   for(let n=0;n<data.length;n++)data[n]=(Math.random()*2-1)*Math.pow(1-n/data.length,2);
   const source=ctx.createBufferSource(),filter=ctx.createBiquadFilter(),gain=ctx.createGain();
   source.buffer=buffer;filter.type='bandpass';filter.frequency.value=700+i*230;filter.Q.value=.8;
   gain.gain.setValueAtTime(.9-i*.1,now+t);gain.gain.exponentialRampToValueAtTime(.001,now+t+duration);
   source.connect(filter);filter.connect(gain);gain.connect(this.master);source.start(now+t);source.stop(now+t+duration);
   const knock=ctx.createOscillator(),body=ctx.createGain();knock.type='triangle';knock.frequency.setValueAtTime(190+i*35,now+t);knock.frequency.exponentialRampToValueAtTime(85,now+t+.04);
   body.gain.setValueAtTime(.22,now+t);body.gain.exponentialRampToValueAtTime(.001,now+t+.065);
   knock.connect(body);body.connect(this.master);knock.start(now+t);knock.stop(now+t+.07);
  }
 }
}

function tone(ctx, output, {note, end, time, duration, volume, type='sine', attack=.025}) {
 const oscillator=ctx.createOscillator(), gain=ctx.createGain();
 oscillator.type=type;
 oscillator.frequency.setValueAtTime(note,time);
 if(end) oscillator.frequency.exponentialRampToValueAtTime(end,time+duration);
 gain.gain.setValueAtTime(.0001,time);
 gain.gain.exponentialRampToValueAtTime(volume,time+attack);
 gain.gain.exponentialRampToValueAtTime(.0001,time+duration);
 oscillator.connect(gain).connect(output);
 oscillator.start(time);
 oscillator.stop(time+duration);
}
const pitch = midi => 440 * 2 ** ((midi-69)/12);
const musicChords = [[45,52,57,60],[41,48,53,57],[48,55,60,64],[43,50,55,59]];
const musicMelody = [[69,72,76,74],[69,65,72,69],[67,72,76,79],[74,71,67,64]];
async function makeMusic() {
 const Offline=globalThis.OfflineAudioContext||globalThis.webkitOfflineAudioContext;
 if(!Offline)return null;
 const sampleRate=22050, beat=.57, ctx=new Offline(1,Math.round(32*beat*sampleRate),sampleRate);
 for(const [bar,chord] of musicChords.entries()){
  const start=bar*8*beat;
  chord.forEach((midi,index)=>tone(ctx,ctx.destination,{
    note:pitch(midi),time:start+.04,duration:8*beat-.12,volume:index===0?.1:.045,type:'sine',attack:.32,
  }));
  for(const [index,note] of musicMelody[bar].entries()){
   const time=start+(index*2+.3)*beat;
   tone(ctx,ctx.destination,{note:pitch(note),time,duration:.91,volume:.065,type:'triangle'});
   tone(ctx,ctx.destination,{note:pitch(note+12),time,duration:.41,volume:.018});
  }
 }
 return ctx.startRendering();
}

export class GameAudio extends DiceAudio {
 constructor(muted){super(muted);this.music=null;this.musicBuffer=null;this.musicWanted=false;}
 async startMusic(){
  this.musicWanted=true;
  if(this.music||this.muted||!this.context||this.context.state!=='running')return;
  try {
   this.musicBuffer ??= makeMusic();
   const buffer=await this.musicBuffer;
   if(!buffer||!this.musicWanted||this.music||this.muted)return;
   const source=this.context.createBufferSource(), gain=this.context.createGain();
   source.buffer=buffer;
   source.loop=true;
   gain.gain.value=.47;
   source.connect(gain).connect(this.master);
   source.start();
   this.music=source;
  } catch { this.musicBuffer=null; }
 }
 stopMusic(){
  this.musicWanted=false;
  if(!this.music)return;
  this.music.stop();
  this.music.disconnect();
  this.music=null;
 }
 cue(kind){
  const ctx=this.context;
  if(this.muted||!ctx||ctx.state!=='running')return;
  const now=ctx.currentTime;
  const notes=(sequence,delay=0)=>sequence.forEach(([midi,offset,duration,volume,type])=>
   tone(ctx,this.master,{note:pitch(midi),time:now+delay+offset,duration,volume,type}));
  if(kind==='start') notes([[50,0,.46,.36,'triangle'],[57,.09,.45,.28,'triangle'],[62,.18,.49,.27,'triangle'],[65,.28,.57,.29,'triangle'],[74,.41,.75,.2,'sine']]);
  if(kind==='pickup') notes([[72,0,.23,.3,'triangle'],[76,.09,.28,.3,'triangle'],[84,.19,.6,.33,'sine']]);
  if(kind==='trap') {
   tone(ctx,this.master,{note:190,end:72,time:now,duration:.29,volume:.32,type:'sawtooth',attack:.015});
   notes([[48,.07,.2,.22,'triangle'],[39,.13,.29,.26,'sine']]);
  }
  if(kind==='portal'){
   tone(ctx,this.master,{note:95,end:560,time:now,duration:.63,volume:.31,type:'triangle',attack:.24});
   tone(ctx,this.master,{note:412,end:96,time:now+.34,duration:1.19,volume:.25,type:'sine',attack:.17});
  }
  if(kind==='death'){
   const roar=ctx.createBuffer(1,Math.round(ctx.sampleRate*.96),ctx.sampleRate);
   const samples=roar.getChannelData(0);
   let pressure=0;
   for(let i=0;i<samples.length;i++){
    pressure=.91*pressure+.09*(Math.random()*2-1);
    samples[i]=pressure*(.64+.36*Math.sin(i/ctx.sampleRate*2*Math.PI*29));
   }
   const source=ctx.createBufferSource(), filter=ctx.createBiquadFilter(), gain=ctx.createGain();
   source.buffer=roar;
   filter.type='lowpass';
   filter.frequency.setValueAtTime(750,now);
   filter.frequency.exponentialRampToValueAtTime(135,now+.95);
   gain.gain.setValueAtTime(.001,now);
   gain.gain.exponentialRampToValueAtTime(1.35,now+.15);
   gain.gain.exponentialRampToValueAtTime(.001,now+.95);
   source.connect(filter).connect(gain).connect(this.master);
   source.start(now);
   tone(ctx,this.master,{note:81,end:37,time:now,duration:.95,volume:.54,type:'sawtooth',attack:.11});
   notes([[57,0,.54,.36,'triangle'],[53,.31,.54,.34,'triangle'],[48,.64,.84,.34,'triangle'],[36,.64,1.1,.39,'sine']],1);
  }
 }
}
