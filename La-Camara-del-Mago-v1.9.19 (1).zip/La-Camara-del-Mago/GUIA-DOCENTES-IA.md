# Crear una sala con ChatGPT

1. Abre **Modo docente** y completa título, tiempo, parejas, número de retos y premio del cofre.
2. Añade los materiales. Los PDF se adjuntan también en ChatGPT. Los TXT, Markdown y apuntes pegados viajan dentro de las instrucciones copiadas. Para usar documentos Word o presentaciones, expórtalos a PDF.
3. Elige nivel y dificultad. Pulsa **Copiar instrucciones y abrir ChatGPT**. Si el navegador bloquea el portapapeles o la pestaña, usa el texto que aparece debajo y el enlace **Abrir ChatGPT**.
4. Pega las instrucciones en ChatGPT, añade los PDF si los hay y envía el mensaje. Copia el bloque JSON que te devuelve.
5. Pégalo en el juego y pulsa **Importar sala y revisar**. Lee las soluciones y referencias, confirma la revisión y pulsa **Abrir sala de clase**. Guarda la unidad si quieres reutilizarla.

El juego pide ejercicios de relacionar, completar, verdadero o falso y, si hay al menos cuatro retos, opción múltiple. La revisión comprueba que la solución esté respaldada por los materiales. Si la importación indica un error, pega el mensaje en ChatGPT y pide que corrija su JSON.

La preparación usa ChatGPT desde el navegador. La sala se crea en el ordenador docente y la partida usa los materiales que cargaste en el juego. Puedes abrir una unidad anterior desde **Cargar unidad o JSON de IA**.
