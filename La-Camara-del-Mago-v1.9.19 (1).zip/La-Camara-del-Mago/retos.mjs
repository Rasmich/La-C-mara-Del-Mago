import { randomInt } from 'node:crypto';

export function normalizar(value) {
  return String(value).normalize('NFD').replace(/\p{M}/gu, '')
    .toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

export function mezclar(items) {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i--) {
    const j = randomInt(i + 1);
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

// El generador local construye problemas de razonamiento con evidencia explícita.
// No oculta palabras ni puntúa redacciones por coincidencia literal.
function extraerEvidencias(sources) {
  const items = [];
  const seen = new Set();
  for (const source of sources) {
    for (const [pageIndex, page] of source.pages.entries()) {
      const sentences = page.replace(/\r/g, '').split(/\n\s*\n|(?<=[.!?;])\s+|\n(?=\s*[-•*])/u);
      for (const raw of sentences) {
        const text = raw.replace(/^\s*[-•*]\s*/, '').replace(/\s+/g, ' ').trim();
        if (text.length < 45 || text.length > 460 || seen.has(normalizar(text))) continue;
        // Se necesitan afirmaciones, no títulos ni listas de palabras sueltas.
        if (!/\b(es|son|consiste|permite|puede|debe|requiere|produce|utiliza|evita|sirve|reparte|alterna|obliga|conviene|tiene|se)\b/iu.test(text)) continue;
        seen.add(normalizar(text));
        items.push({ text, source: source.name, reference: source.pdf ? `${source.name}, pág. ${pageIndex + 1}` : source.name });
      }
    }
  }
  return items;
}

// Las decisiones dependen del contenido, no de una respuesta genérica sobre A y B.
// Solo se invierten afirmaciones simples: no se inventan conocimientos de la materia.
function invertir(text) {
  if (/\b(no|nunca|jamás|excepto|sin|siempre|todos|todas|ningún)\b/iu.test(text)) return null;
  const verb = /\b(es|son|consiste|permite|puede|debe|requiere|produce|utiliza|evita|sirve|reparte|alterna|obliga|conviene|tiene)\b/iu;
  return verb.test(text) ? text.replace(verb, 'no $1') : null;
}
const escenas = [
  ['El informe del aprendiz', 'Un aprendiz ha preparado un informe para resolver un problema de la unidad. El guardián sospecha que ha mezclado ideas válidas con conclusiones que contradicen los apuntes. Tenéis que auditar cada afirmación antes de autorizar su propuesta.'],
  ['El consejo de las tres voces', 'Tres consejeros defienden las afirmaciones siguientes. No podéis decidir por mayoría: cada intervención debe contrastarse con los conceptos estudiados. Vuestra decisión determinará qué recomendaciones se conservan en el archivo.'],
  ['La reparación del archivo', 'Un hechizo ha alterado algunas relaciones del archivo de la unidad. Se conservan los términos, pero puede haberse invertido su significado. Recuperad la coherencia del documento y justificad qué habría que corregir.'],
  ['La revisión del proyecto', 'Antes de ejecutar un proyecto, vuestra pareja revisa sus fundamentos. Cada afirmación representa un supuesto del plan. Un supuesto incompatible con el material puede hacer fallar todo el procedimiento; revisadlos uno a uno.'],
  ['El dictamen de la biblioteca', 'La biblioteca recibe tres conclusiones sobre la materia. Debéis emitir un dictamen fundamentado: distinguir las compatibles con el material de las que lo contradicen y explicar cómo reparar una conclusión incorrecta.'],
];
export function generarRetos(sources, count) {
  const evidence = mezclar(extraerEvidencias(sources).filter(item => invertir(item.text)));
  if (evidence.length < 3) return [];
  // No se repite un mismo conjunto, aunque el orden sea distinto.
  const combinations = [];
  for (let a = 0; a < evidence.length && combinations.length < 160; a++)
    for (let b = a + 1; b < evidence.length && combinations.length < 160; b++)
      for (let c = b + 1; c < evidence.length && combinations.length < 160; c++)
        combinations.push([evidence[a], evidence[b], evidence[c]]);
  return mezclar(combinations).slice(0, count).map((items, index) => {
    const [title, scene] = escenas[index % escenas.length];
    const mask = 1 + randomInt(6); // Al menos una compatible y una contradictoria.
    const describe = value => [0, 1, 2].map(i => `${i + 1}: ${value & (1 << i) ? 'compatible' : 'contradice'}`).join(' · ');
    const answer = describe(mask);
    const alternatives = mezclar(Array.from({ length: 8 }, (_, i) => i).filter(i => i !== mask)).slice(0, 3);
    const assertions = items.map((item, i) => `${i + 1}. ${mask & (1 << i) ? item.text : invertir(item.text)}`).join('\n\n');
    const refs = [...new Set(items.map(item => item.reference))].join('; ');
    return {
      title: `${title}${index >= escenas.length ? ' II' : ''}`,
      prompt: `${scene}\n\n${assertions}\n\nConsultad ${refs}. Clasificad las tres afirmaciones como compatibles o contradictorias con lo estudiado. Después elegid el dictamen completo.\n\nSeleccionad el dictamen que clasifica correctamente las tres afirmaciones. Una persona contrasta las fuentes y la otra busca un posible error en vuestro razonamiento.`,
      options: mezclar([answer, ...alternatives.map(describe)]), answers: [answer],
      reasoningRequired: false,
      hint: `Contrastad cada relación con ${refs}. Comprobad qué afirma y qué niega cada frase; una palabra puede invertir su significado.`,
    };
  });
}

export const demo = {
  title: 'La prueba del Mago',
  minutes: 60,
  training: false,
  maxRolls: 3,
  reward: '¡Habéis abierto el cofre de la demo! Ignar os concede el título de Guardianes del Umbral.',
  sources: [{
    name: 'Guía de la expedición de prueba',
    text: 'Podéis pedir dos pistas por sello. El primer fallo os saca de la sala, el segundo os devuelve a la casilla inicial y al tercero os derrota Ignar. Anotad la runa y la cifra que ganéis en cada reto. Al llegar al cofre, ordenad las cifras según sus runas.',
  }],
  challenges: [
    {
      kind: 'fill',
      title: 'La suma del guardián',
      prompt: 'Tenéis 7 monedas en la bolsa y encontráis otras 5. ¿Cuántas monedas tenéis en total? Escribid el número.',
      options: [],
      answers: ['12', 'doce', '12 monedas', 'doce monedas'],
      strategy: 'Partid de 7 y contad cinco monedas más.',
      hint: '7 + 5 = 12. Escribid 12.',
      explanation: 'Al sumar las 7 monedas de la bolsa y las 5 encontradas, obtenéis 12 monedas.',
    },
    {
      kind: 'choice',
      title: 'La luz del Umbral',
      prompt: '¿A qué velocidad aproximada viaja la luz en el vacío?',
      options: ['300 kilómetros por segundo', '30 000 kilómetros por segundo', '300 000 kilómetros por segundo'],
      answers: ['300 000 kilómetros por segundo'],
      strategy: 'Buscad la opción que equivale a casi 300 millones de metros cada segundo.',
      hint: 'La luz recorre aproximadamente 300 000 kilómetros en un segundo.',
      explanation: 'La velocidad de la luz en el vacío es de 299 792 458 metros por segundo, unos 300 000 kilómetros por segundo.',
      reference: 'NIST · CODATA, velocidad de la luz en el vacío',
    },
    {
      kind: 'choice',
      title: 'La caída de la piedra',
      prompt: 'Ignar deja caer una piedra. Cerca de la superficie de la Tierra y sin contar el aire, ¿cuánto aumenta aproximadamente su velocidad hacia abajo cada segundo?',
      options: ['9,8 metros por segundo', '98 metros por segundo', '0,98 metros por segundo'],
      answers: ['9,8 metros por segundo'],
      strategy: 'Pensad en un aumento cercano a 10 metros por segundo cada segundo.',
      hint: 'La primera opción es correcta. La aceleración se aproxima a 9,8 metros por segundo al cuadrado.',
      explanation: 'La aceleración de la gravedad es de unos 9,8 m/s² cerca de la superficie. En caída libre, la velocidad aumenta aproximadamente 9,8 m/s cada segundo.',
      reference: 'NIST · Guía del SI, aceleración estándar de caída libre',
    },
  ],
};
