# La Cámara del Mago · 1.9.19

Consulta [AUDITORIA.md](AUDITORIA.md) para ver los cambios, las pruebas y la propuesta de uso en clase. El selector **Modo de partida** permite elegir **Clásico** o **Aula** al preparar una sala.

Escape room de aula para parejas. Elegid el recorrido por el mapa cuadrado, revelad salas y resolved los sellos para conseguir las runas del cofre.

## Arrancar

1. Extrae el ZIP completo en el ordenador docente.
2. En Windows de 64 bits, haz doble clic en **Jugar.cmd**. La primera vez necesita Internet para descargar Node.js en la cache del usuario si hace falta e instalar las dependencias. Cuando el servidor esté listo, se abrirá el navegador. Mantén abierta la ventana durante la clase. Si el puerto 8787 está ocupado, el lanzador abre la versión recién iniciada en el siguiente puerto libre. Si usas otro sistema, instala [Node.js 24 o posterior](https://nodejs.org/en/download), ejecuta `npm ci` la primera vez y después `npm start`.
3. Abre [la portada del juego](http://localhost:8787/). Pulsa **Probar la demo** para jugar tres retos breves de cálculo y cultura general, probar el encuentro con Ignar y abrir el cofre. La demo usa el modo Clásico y empieza con tres tiradas disponibles por sello.
4. Para preparar una unidad, pulsa **Modo docente** en la página local o abre [el acceso docente](http://localhost:8787/docente) desde el equipo que ejecuta el juego.

## Crear sala con ChatGPT

En **Modo docente**, añade materiales y pulsa **Copiar instrucciones y abrir ChatGPT**. Pega las instrucciones y adjunta los PDF en ChatGPT. Copia el resultado, pégalo en **Importar sala y revisar** y abre la sala tras revisar los retos. Consulta **GUIA-DOCENTES-IA.md**.

## Preparar la clase con el generador local básico

1. Indica cuántas parejas jugarán y añade PDF, TXT, Markdown o apuntes. Escribe el texto de cierre en **Premio del cofre**. Por defecto se preparan tres retos en 60 minutos y puedes cambiar estos valores en los ajustes opcionales.
2. Pulsa **Generar borrador de retos**. El generador local prepara casos de revisión de informes, debates y reparación de conclusiones con tres afirmaciones de la materia. La pareja contrasta su compatibilidad con las fuentes, detecta contradicciones y escribe una corrección con un ejemplo. Las pistas señalan el material y la página del PDF. Revisa las propuestas antes de publicarlas: es un generador local de contraste de afirmaciones, no un modelo que comprenda cualquier materia o evalúe redacciones. Puedes editar todos los enunciados y convertirlos en problemas de aplicación propios.
3. Usa **Guardar unidad** para reutilizarla en otra clase. El archivo JSON incluye los materiales, las soluciones y la recompensa. Guárdalo en el equipo docente.
4. Pulsa **Abrir sala de clase** y comparte el enlace con el grupo. En **Códigos privados de pareja**, asigna un código distinto a cada equipo y entrégalo en privado. En **Ver progreso de las parejas** puedes ver los sellos completados y las respuestas incorrectas.

Las salas de clase se guardan automáticamente. Para retomarlas, inicia el juego desde la misma carpeta y ve a **Modo docente → Salas abiertas**. Elige la sala y comparte el enlace actualizado si cambió la dirección del equipo. Las parejas usan sus mismos códigos y recuperan su posición, vida, objetos, pistas, sellos y tiempo restante. El tiempo de juego se pausa mientras el servidor está cerrado.

Los datos se guardan en `datos/partidas.sqlite`. Con el juego cerrado, puedes copiar la carpeta `datos` para hacer una copia de seguridad. La demo y la prueba del docente son temporales. Para reutilizar los retos con otro grupo, sigue usando **Guardar unidad**.

Cada pareja usa un dispositivo y alterna quién busca en los materiales y quién propone la respuesta. Su temporizador arranca la primera vez que entra con el código.

Para probar tu propia sala, pulsa **Probar como alumno** en el panel docente, elige una raza y después **Empezar expedición**. La prueba usa tus retos, tus materiales y la recompensa exacta configurada. Al abrir el cofre se muestra ese texto completo, con sus saltos de línea. La recompensa permanece oculta a las parejas hasta abrirlo. Para volver a la actividad publicada, pulsa **Modo docente**. También puedes jugar a la demo desde el inicio.

## Mapa, movimiento y salas

En **Modo docente → Ajustes opcionales de la sala → Tiradas máximas por sello** puedes configurar el límite. Las salas nuevas y la demo empiezan con tres. Usa **0** para jugar sin límite. Cuando queda una tirada, el tablero avisa. Con la última puedes entrar si alguna puerta del sello está al alcance. Acabar el movimiento fuera cuesta una vida y repone las tiradas si sobrevives. Si un fallo de respuesta te expulsa con las tiradas agotadas, solo puedes volver al objetivo para reintentar.

Cada paso cruza una casilla contigua en horizontal o vertical. El tablero muestra el resultado del dado, las bonificaciones y el alcance total. Puedes usar una brújula por movimiento. Si la activas con el dado ya tirado, se aplica a ese movimiento.

Todas las puertas llevan el número del reto, incluidas las entradas alternativas. Los objetos se marcan con el mismo rombo ◆. Termina el movimiento en su casilla para descubrir qué objeto contiene y añadirlo a la Bolsa. También puedes pasar por ella de camino a otro destino.

El tablero tiene acabado de mapa de mesa con piedra envejecida, pasillos ocres y una muralla perimetral. Cada sala tiene su propio motivo de suelo y un emblema junto al objetivo o al entrar. La cuadrícula y los resaltados de movimiento indican qué casillas podéis alcanzar.

La cuadrícula táctica de 15 × 15 está enmarcada como un plano de piedra y latón. Las columnas del eje X se identifican con letras de A a O y las filas del eje Y con números del 1 al 15; cada casilla incluye su coordenada, por ejemplo H8. El dado tridimensional es un dodecaedro regular con doce caras pentagonales. Al tirar, gira y rebota sobre una sombra fija. El número obtenido, del 1 al 12, queda en la cara superior. El panel encima del mapa indica el próximo desafío y su puerta. Tras tirar, usad el botón de avance o seleccionad otra casilla iluminada. Al cruzar la puerta del desafío actual, pulsad «Ir al desafío» para responder. Las puertas de desafíos posteriores tienen un candado que explica cuándo se pueden usar. El tablero ofrece hasta 18 puertas y entradas alternativas a las salas; al abrir una, aparece la ilustración de la estancia. El marcador de la pareja usa el retrato de la raza elegida y las rutas, puertas y hallazgos tienen animaciones suaves. Los sellos detienen el avance y el número de pasos puede variar por los objetos y las habilidades de raza. El juego coloca entre tres y ocho sellos automáticamente y desbloquea sus salas en orden.

Cada reto esconde una trampa en la puerta a la que se llega en menos pasos desde la casilla inicial. Si una pareja la activa, pierde un punto de vida y retrocede una casilla. La pasiva enana o un amuleto pueden evitar el daño. El mecanismo se gasta una sola vez por pareja y la puerta queda libre. Si la vida llega a cero, la partida termina. Hay 11 objetos repartidos por el tablero y la sección del inventario se llama **Bolsa**. Además del reloj, la poción, la brújula y el amuleto, el pergamino de estudio revela la siguiente pista cuando se usa durante un reto.

Al descubrir el Santuario, el mapa muestra el cofre cerrado junto al sello. Tras superar el último reto, el cofre se ilumina. Seleccionad su símbolo **▣** para ir al formulario de combinación. Si falláis la combinación, saldréis del Santuario y tendréis que regresar. Conserváis las runas ganadas. Al abrir el cofre, veréis la recompensa configurada por el docente.

En Clásico, cada sello y el cofre tienen su propio contador de fallos. El primero os deja en el pasillo junto a la puerta. El segundo os devuelve a la casilla inicial. Al tercero, Ignar os derrota y termina la partida. En Aula se puede reintentar en el mismo sello, salvo en el último reto, que expulsa al equipo del Santuario.

Los enanos neutralizan hasta tres trampas. Los orcos aprovechan tiradas altas. Los no muertos ganan un paso tras cada uno de los dos primeros sellos. Los elfos mejoran tiradas bajas y los humanos reciben un paso en sus tres primeros movimientos. Las habilidades se activan automáticamente y tienen usos limitados.

## Justificaciones de las parejas

Por defecto, los retos nuevos solo piden seleccionar una opción o responder brevemente. El docente puede activar, de forma opcional, una explicación escrita de al menos 60 caracteres. El juego valida la elección del dictamen y guarda la explicación al superar el sello. En **Ver progreso de las parejas → Ver justificaciones**, el docente puede revisarlas. La longitud del texto no acredita que su razonamiento sea correcto: no se califican automáticamente. La casilla de cada reto permite activar o desactivar este requisito, y se conserva al guardar o cargar una unidad.

## Red y supervisión

Los equipos pueden tener acceso a Internet. Para jugar desde varios dispositivos, deben poder comunicarse con el ordenador docente por la red del aula. Durante la actividad, las parejas solo deben tener abiertas las pestañas del juego y sus materiales. La supervisión de pantallas se realiza desde Veyond por separado. Para jugar solo en el ordenador docente, arranca con `npm start -- --local`.

La generación extrae texto seleccionable de los PDF. Para documentos escaneados, conserva el PDF como material de consulta y añade una transcripción en el campo de apuntes. Si el material es breve o no contiene suficientes pasajes, el borrador puede traer menos retos de los solicitados. Se pueden añadir a mano en el editor.

## Dragón, ilustraciones y derrota

Los dos últimos retos representan las dos fases de Ignar. Tras derrotarlo, las runas permiten abrir el cofre. El tercer fallo en Clásico o la pérdida de los tres puntos de vida activa la escena de derrota. Las unidades guardadas y los JSON de IA conservan su formato.

## Correccion del arranque en Windows

El lanzador extrae Node.js directamente en una carpeta nueva de `%LOCALAPPDATA%/LaCamaraDelMago/runtime`, sin mover ni renombrar directorios despues de la descarga. Esto evita el paso Move que podia fallar con Acceso denegado. Las instalaciones completas se reutilizan y los intentos incompletos no se toman por instalaciones validas. Se mantiene la comprobacion SHA-256 de la descarga.

Si falla un paso, la consola identifica si estaba preparando Node, instalando dependencias o iniciando el servidor. Para actualizar el juego, extrae el ZIP completo en una carpeta nueva y ejecuta Jugar.cmd.
