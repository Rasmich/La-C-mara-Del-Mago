import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { deserialize, serialize } from 'node:v8';

// El material de la sala se guarda una vez. Cada turno escribe solo la pareja afectada.
export function openClassroomStore(filename) {
  mkdirSync(dirname(filename), { recursive: true, mode: 0o700 });
  const db = new DatabaseSync(filename);
  try {
    db.exec(`
      PRAGMA locking_mode = EXCLUSIVE;
      PRAGMA synchronous = FULL;
      CREATE TABLE IF NOT EXISTS classrooms (code TEXT PRIMARY KEY, data BLOB NOT NULL);
      CREATE TABLE IF NOT EXISTS teams (
        code TEXT NOT NULL REFERENCES classrooms(code),
        token TEXT NOT NULL,
        pass TEXT NOT NULL,
        data BLOB NOT NULL,
        PRIMARY KEY (code, token),
        UNIQUE (code, pass)
      );
      CREATE TABLE IF NOT EXISTS heartbeat (id INTEGER PRIMARY KEY CHECK (id = 1), time INTEGER NOT NULL);
    `);
    const beat = db.prepare('INSERT INTO heartbeat VALUES (1, ?) ON CONFLICT(id) DO UPDATE SET time = excluded.time');
    const insertRoom = db.prepare('INSERT INTO classrooms VALUES (?, ?)');
    const insertTeam = db.prepare('INSERT INTO teams VALUES (?, ?, ?, ?)');
    const updateTeam = db.prepare('UPDATE teams SET data = ? WHERE code = ? AND token = ?');
    function transaction(work, time = Date.now()) {
      db.exec('BEGIN EXCLUSIVE');
      try {
        work();
        beat.run(time);
        db.exec('COMMIT');
      } catch (error) {
        db.exec('ROLLBACK');
        throw error;
      }
    }

    const rooms = new Map();
    const now = Date.now();
    transaction(() => {
      const last = db.prepare('SELECT time FROM heartbeat WHERE id = 1').get()?.time ?? now;
      const offline = Math.max(0, now - last);
      for (const { code, data } of db.prepare('SELECT code, data FROM classrooms ORDER BY rowid').iterate()) {
        const { passCodes, ...definition } = deserialize(data);
        rooms.set(code, {
          ...definition,
          teams: new Map(),
          passes: new Map(passCodes.map(pass => [pass, null])),
        });
      }
      for (const { code, token, pass, data } of db.prepare('SELECT code, token, pass, data FROM teams ORDER BY rowid').all()) {
        const room = rooms.get(code);
        const team = deserialize(data);
        if (team.finishedAt === null && team.deadAt == null) {
          team.deadline += offline;
          if (team.retryAt > last) team.retryAt += offline;
          updateTeam.run(serialize(team), code, token);
        }
        room.teams.set(token, team);
        room.passes.set(pass, token);
      }
    }, now);

    return {
      rooms,
      saveRoom(code, room) {
        const { teams, passes, ...definition } = room;
        transaction(() => insertRoom.run(code, serialize({ ...definition, passCodes: [...passes.keys()] })));
      },
      saveTeam(code, token, team, pass) {
        transaction(() => {
          const data = serialize(team);
          if (pass) insertTeam.run(code, token, pass, data);
          else if (updateTeam.run(data, code, token).changes !== 1) throw new Error('La partida no está registrada.');
        });
      },
      tick: () => beat.run(Date.now()),
      close() { db.close(); },
    };
  } catch (error) {
    db.close();
    throw error;
  }
}
